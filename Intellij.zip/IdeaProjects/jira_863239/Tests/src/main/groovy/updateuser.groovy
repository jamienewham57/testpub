import groovy.transform.ToString

import java.text.SimpleDateFormat

@ToString

class Morons {
    Number id
    String firstName
    String lastName
    String email
    Date dob

    Morons(Number id, String firstName, String lastName, String email, String dob) {
        this.id = id
        this.firstName = firstName
        this.lastName = lastName
        this.email = email
        this.dob = new SimpleDateFormat('dd/MM/yyyy').parse(dob)
    }

    void printFullName(){
        println "Output: $firstName $lastName is honking"
    }
}

Morons ff = new Morons(1001,"Ed", "Fox", "fat.fox@honk.com", '09/04/1965')

println ff
ff.printFullName()