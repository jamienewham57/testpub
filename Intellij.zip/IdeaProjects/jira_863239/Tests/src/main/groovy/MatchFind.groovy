def text = ["Jamie Newham was born in Nottingham", "Nottingham is cool" ] as String
def pattern = ~/Nottingham/
def finder = text =~ pattern
def matcher = text ==~ pattern
println finder.size()
println matcher

text = text.replaceAll(pattern, "London")

println text

