def nums = [1,2,3,4,5,4,6,7,8,9]
println nums

// add

nums << 99

nums.push(999)

nums.putAt(3,9999)

nums[0]= 79

println nums + [86,7,6]

println nums

// remove

nums.pop()
nums.removeAt(2)

def newList = nums - 5

println nums
println newList

// get

println nums[2]
println newList.getAt(1..5)

// clear

// nums.clear() // comment out to allow println x to work otherwise just empty list array
println nums

for (x in nums){
    println x
}

// flatten

nums << [7,6,7]
nums << [9,89]
println nums

println nums.flatten()

println nums.flatten().unique()

// set

def numbers = [1,2,3,4,3,3,4,5,3,6,8,8,8,5,5,72] as Set // SortedSet to sort in order
println numbers