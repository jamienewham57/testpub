def tweet = new Tweet("themilktray" , "Hello, Twitter!!")
tweet.addToFavourites()
println tweet