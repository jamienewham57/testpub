def map = [:]

println map.getClass().getName()

def person = [first: "jamie", last: "newham", email: "jamienewham@gmail.com"]

println person.first

person.twitter = "@themilktray"

println person


def email = "This is your email address"
def twitter = [userName: "@themilktray" , (email): "jamienewham@gmail.com"]
println twitter

println twitter.size()
println twitter.sort()

// looping through person


for (attribute in person) {

    println attribute
}

for (item in person.keySet()){
    println "$item:${person[item]}"

}