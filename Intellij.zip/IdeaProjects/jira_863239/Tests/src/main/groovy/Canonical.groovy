import groovy.transform.Canonical
@groovy.transform.Canonical
class CustomerTwo {
    String first, last
    int age
    Date since
    Collection favItems = ['Food']
    def object
}
def d = new Date()
def anyObject = new Object()
def c1 = new CustomerTwo(first:'Tom', last:'Jones', age:21, since:d, favItems:['Books', 'Games'], object: anyObject)
def c2 = new CustomerTwo('Tom', 'Jones', 21, d, ['Books', 'Games'], anyObject)
assert c1 == c2