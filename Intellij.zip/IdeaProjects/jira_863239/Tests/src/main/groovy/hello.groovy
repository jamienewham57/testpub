class Person{
    def sayHello() { println( "Hello Nob Head")}
}
jamie = new Person()
jamie.sayHello()
