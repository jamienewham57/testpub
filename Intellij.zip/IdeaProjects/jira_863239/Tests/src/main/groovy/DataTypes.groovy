// Java Primitive

//        byte
//        Min Value: -128
//        Max Value: 127

//        short:
//        Min Value: -31,768
//        Max Value: 32,767

//        int:
//        Min Value: -2,147,483,648 (-2^31)
//        Max Value: 2,147,483,647 (2^31 - 1)

//        long:
//        Min Value: (-2^63)
//        Max Value: (2^63 -1)

//        float: 32-bits IEEE floating points (single precision)
//        Min Value: 1.4E-45
//        Max Value: 3.4028235E38

//        double: 64-bit IEEE floating points (double precision)
//        Min Value: 4.9E-324
//        Max Value: 1.7976931348623157E308

//        char: character or unicode

//        boolean: true or false

