import groovy.transform.*

@ToString
@groovy.transform.Sortable

class Ppl {

    String first
    String last
}

def p1 = new Ppl(first:"Joe", last: "Bloggs")
def p2 = new Ppl(first:"Dab", last:"Vega")

def CombPpl = [p1,p2]

println CombPpl
