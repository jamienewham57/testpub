import scalaz.Alpha

enum colours{
    orange,
    blue,
    green

}

println colours.values()

enum Days{
    monday,
    tuesday,
    wednesday,
    thursday,
    friday,
    saturday,
    sunday
}

println Days.values().size()


def weekDays = Days.monday..Days.friday

println weekDays
println weekDays.size()
println weekDays.contains(Days.wednesday)
println weekDays.from
println weekDays.to

def DaysList = ["monday", "tuesday", "wednesday" , "thursday" , "friday" , "saturday" , "sunday"]
println DaysList
println DaysList.size()

DaysList = DaysList - "saturday"
println DaysList

DaysList.add(5, "saturday")
println DaysList

println DaysList[2]


def DaysMap = [1:"monday", 2:"tuesday", 3:"wednesday", 4:"thursday", 5:"friday", 6:"saturday", 7:"sunday"]
println DaysMap
println DaysMap.getClass().getName()
println DaysMap.size()
println DaysMap.values()


for (days in DaysMap.values()){
    println days
}