import groovy.transform.ToString
@ToString
class Developer {

    String first
    String last
    def languages = []

    void work() { println "$first $last is working hard..." }

//    Developer(String first, String last) {
//        this.first = first
//        this.last = last
//    }

}