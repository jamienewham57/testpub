import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.history.ChangeItemBean

// This script will show the time this issue remained "In Progress"

def changehistory = ComponentAccessor.getChangeHistoryManager()
def inProg = "In Progress"

List<Long> rt = [0L]

def changeItems = changehistory.getChangeItemsForField(issue, "status")
changeItems.reverse().each { ChangeItemBean item ->

    def timeDiff = System.currentTimeMillis() - item.created.getTime()

    if (item.fromString == inProg) {
        rt << -timeDiff
    }
    if ( item.toString == inProg) {
        rt << timeDiff
    }
}

def Total = rt.sum() as Long

return(Total / 1000) as Long ?: 0L