0.step(1000,10) {
    num ->
        println num
}
