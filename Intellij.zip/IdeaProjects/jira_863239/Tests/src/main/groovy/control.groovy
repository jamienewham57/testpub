// if
if( true )
    println "Value is true!"
// flase | null | empty strings

if (false)
    println "Value is false!"

String last =""
if(last)
    println "last has a value"

// if/else
def x = 10
if( x ==10 ){
    println "x is 10"
} else {
    println " x is not 10"
}

// classic while

def i = 1
while( i <=10 ) {
    println i
    i += 2
}

// for in list

def list = [1,2,3,4]
for( num in list ){
    println num
}

// closure

def list2 = [1,2,3,4]
list2.each {println it}
//println list2

// switch
def myNumber = 10

switch(myNumber) {
    case 1:
        println "number is 1"
        break
    default:
        println "default case"
}


