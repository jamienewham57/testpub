def d = new Developer()
d.first = "Jamie"
d.last = "Newham"

d.languages << "Groovy"
d.languages << "C++"

println d