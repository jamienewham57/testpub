import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.fields.config.manager.IssueTypeSchemeManager
import com.atlassian.jira.project.Project
import com.atlassian.jira.project.ProjectManager
import org.ofbiz.core.entity.GenericValue
import com.atlassian.jira.ManagerFactory
import java.util.List
import java.util.ArrayList
import java.util.Map
import java.util.HashMap
import java.lang.StringBuilder
 
def projectManager = ComponentAccessor.getProjectManager()
def notificationSchemeManager = ComponentAccessor.getNotificationSchemeManager()
def permissionSchemeManager = ComponentAccessor.getPermissionSchemeManager()
def issueSecuritySchemeManager = ManagerFactory.getIssueSecuritySchemeManager()
def issueTypeSchemeManager = (IssueTypeSchemeManager) ComponentManager.getInstance().getComponentInstanceOfType(IssueTypeSchemeManager.class)
def workflowSchemeManager = ComponentManager.getInstance().getWorkflowSchemeManager()
def fieldLayoutManager = ComponentManager.getInstance().getFieldLayoutManager()
def issueTypeScreenSchemeManager = ComponentManager.getInstance().getIssueTypeScreenSchemeManager()
 
List<ProjectAttributes> projectsAttributes = new ArrayList<ProjectAttributes>()
Map<Integer,List<ProjectAttributes>> categorizedProjects = new HashMap<Integer,List<ProjectAttributes>>()
 
for(def project : projectManager.getProjectObjects()) {
        GenericValue srcProjectGV = project.getGenericValue()
 
        def projectAttributes = new ProjectAttributes()
        projectAttributes.projectKey = project.key
        projectAttributes.projectName = project.name
        projectAttributes.permissionScheme = permissionSchemeManager.getSchemes(srcProjectGV).size() == 0 ? "none" : permissionSchemeManager.getSchemes(srcProjectGV)[0].getString("name")
        projectAttributes.notificationScheme = notificationSchemeManager.getNotificationSchemeForProject(srcProjectGV) == null ? "none" : notificationSchemeManager.getNotificationSchemeForProject(srcProjectGV).getString("name")
        if(issueSecuritySchemeManager.getSchemes(srcProjectGV)[0] != null) {
            projectAttributes.issueSecurityScheme = issueSecuritySchemeManager.getSchemes(srcProjectGV)[0].getString("name")
        } else {
            projectAttributes.issueSecurityScheme = "none"
        }
        projectAttributes.workflowScheme = workflowSchemeManager.getSchemes(srcProjectGV).size() == 0 ? "none" : workflowSchemeManager.getSchemes(srcProjectGV)[0].getString("name")
        projectAttributes.fieldConfigurationScheme = fieldLayoutManager.getFieldConfigurationScheme(srcProjectGV) == null ? "none" : fieldLayoutManager.getFieldConfigurationScheme(srcProjectGV).getName()
        projectAttributes.issueTypeScheme = issueTypeSchemeManager.getConfigScheme(srcProjectGV).getName()
        projectAttributes.issueTypeScreenScheme = issueTypeScreenSchemeManager.getIssueTypeScreenScheme(srcProjectGV).getName()
 
        projectsAttributes.add(projectAttributes);
}
 
Integer categoryCounter = 1;
for(ProjectAttributes attributes : projectsAttributes) {
    boolean addCategory = true;
    for(Map.Entry<Integer,List<ProjectAttributes>> entry : categorizedProjects.entrySet()) {
        Integer key = entry.getKey()
        List<ProjectAttributes> value = entry.getValue()
         
        if(entry != null) {
            if(value.get(0) != null) {
                if(attributes.equals(value.get(0))) {
                    value.add(attributes);
                    addCategory = false;
                    break;
                }
            }
        }
    }
     
    if(addCategory) {
        categorizedProjects.put(categoryCounter++,[attributes])
    }
}
 
StringBuilder sb = new StringBuilder();
for(Map.Entry<Integer,List<ProjectAttributes>> entry : categorizedProjects.entrySet()) {
    Integer key = entry.getKey()
    List<ProjectAttributes> value = entry.getValue()
     
    sb.append(key + "\n")
    for(ProjectAttributes attr : value) {
        sb.append(attr.projectKey + "\t" + attr.projectName + "\t" + attr.permissionScheme + "\t" + attr.notificationScheme + "\t" + attr.issueSecurityScheme + "\t" + attr.workflowScheme + "\t" + attr.issueTypeScheme + "\t" + attr.fieldConfigurationScheme + "\t" + attr.issueTypeScreenScheme + "\n")
    }
}
 
return sb.toString();
 
private class ProjectAttributes {
    public String projectKey
    public String projectName
    public String permissionScheme
    public String notificationScheme
    public String issueSecurityScheme
    public String workflowScheme
    public String issueTypeScheme
    public String fieldConfigurationScheme
    public String issueTypeScreenScheme
     
    private boolean equals(ProjectAttributes attributes) {
        return attributes.permissionScheme.equals(this.permissionScheme) && attributes.notificationScheme.equals(this.notificationScheme) && attributes.issueSecurityScheme.equals(this.issueSecurityScheme) && attributes.workflowScheme.equals(this.workflowScheme) && attributes.issueTypeScheme.equals(this.issueTypeScheme) && attributes.fieldConfigurationScheme.equals(this.fieldConfigurationScheme) && attributes.issueTypeScreenScheme.equals(this.issueTypeScreenScheme)
    }
}