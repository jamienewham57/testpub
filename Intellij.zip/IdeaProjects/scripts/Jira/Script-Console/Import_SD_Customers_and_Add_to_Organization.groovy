import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.user.util.UserUtil;
 
//Managers
UserManager um = ComponentAccessor.getUserManager()
UserUtil uu = ComponentAccessor.getUserUtil()
 
//Shell file to set REST calls for Organizations memberships
def orgaMembersFile = new File('/var/atlassian/application-data/jira/tmp/orgaMembers.sh')
orgaMembersFile.append("#!/bin/sh")
orgaMembersFile.append("\n")
 
//Groups definition
Group grpCustomers = um.getGroup("jira-servicedesk-customers")
Group grpUsers = um.getGroup("jira-users")
 
//Implementation variables
String displayName
 
//Create users from CSV file
//Columns of the CSV file in this case:
//Login;Email;LastName;FirstName;OrganizationName
new File("/<JIRA_HOME>/tmp/Users_List.csv").splitEachLine(";") { usr ->
     
    if (usr[3] == '') {
        displayName = usr[2]   
    } else {
        displayName = usr[3]+' '+usr[2]
    }
     
    //Cast of the password to "Jira123" in this case
    ApplicationUser user = uu.createUserNoNotification(usr[0], "Jira123", usr[1], displayName)
    uu.addUserToGroup(grpCustomers, user)
    uu.removeUserFromGroup(grpUsers, user)
 
    //Generate the REST commands to add each User to an Organization
    //Columns of the CSV file in this case:
    //OrganizationId;OrganizationName
    new File("/<JIRA_HOME>/tmp/Organizations.csv").splitEachLine(",") { orga ->
        
        if (orga[1] == usr[4]) {
            orgaMembersFile.append("\ncurl -X POST -H \"Authorization: Basic <Admin_Credentials_Base64>\" -H \"Content-Type: application/json\" -H \"X-ExperimentalApi: opt-in\" -d '{\"usernames\": [\""+usr[0]+"\"]}' <JIRA_BASE_URL>/rest/servicedeskapi/organization/{"+orga[0]+"}/user")
        }
    }
}