import com.atlassian.crowd.embedded.api.User
import com.atlassian.crowd.embedded.impl.ImmutableUser
import com.atlassian.jira.bc.user.UserService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.util.UserManager
  
UserManager userManager = ComponentAccessor.getUserManager()
UserService userService = ComponentAccessor.getComponent(UserService.class)
User updateUser
UserService.UpdateUserValidationResult updateUserValidationResult
  
errors = ''
userManager.getUsers().findAll{user -> user.name == 'username'}.each { user ->
    updateUser = ImmutableUser.newUser(user).active(false).toUser()
    updateUserValidationResult = userService.validateUpdateUser(updateUser)
    if (updateUserValidationResult.isValid()) {
        userService.updateUser(updateUserValidationResult)
    } else {
        errors += "Update of ${user.name} failed: ${updateUserValidationResult.getErrorCollection().getErrors().entrySet().join(',')}\n"
    }
}
return errors