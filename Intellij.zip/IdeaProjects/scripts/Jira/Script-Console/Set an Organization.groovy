import com.atlassian.fugue.Option
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.servicedesk.api.ServiceDesk
import com.atlassian.servicedesk.api.ServiceDeskManager
import com.atlassian.servicedesk.api.organization.OrganizationService
import com.atlassian.servicedesk.api.organization.OrganizationsQuery
import com.atlassian.servicedesk.api.organization.CustomerOrganization
import com.atlassian.servicedesk.api.util.paging.LimitedPagedRequest
import com.atlassian.servicedesk.api.util.paging.LimitedPagedRequestImpl
import com.atlassian.fugue.Either
import com.atlassian.pocketknife.api.commons.error.AnError
import com.onresolve.scriptrunner.runner.customisers.PluginModule
import com.onresolve.scriptrunner.runner.customisers.WithPlugin
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.event.type.EventDispatchOption
import org.apache.log4j.Category
  
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG);
  
@WithPlugin("com.atlassian.servicedesk")
  
@PluginModule
OrganizationService organizationService
  
IssueManager issueManager = ComponentAccessor.getIssueManager();
ApplicationUser currentUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser();
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager();
 
Integer ORGANIZATION_ID = 2 //Table AO_54307E_ORGANIZATION
long ID_CF_ORGA =10103; //CF id
 
CustomField cfOrganization = customFieldManager.getCustomFieldObject(ID_CF_ORGA);
 
//Mock Issue
String issueKey ="SD-2";
MutableIssue issue = issueManager.getIssueByCurrentKey(issueKey);
 
CustomerOrganization organization = organizationService.getById(currentUser, ORGANIZATION_ID)?.right()?.get();
 
Collection<CustomerOrganization> organizations = new ArrayList<CustomerOrganization>();
organizations.add(organization);
 
issue.setCustomFieldValue(cfOrganization,organizations);
issueManager.updateIssue(currentUser,issue, EventDispatchOption.ISSUE_UPDATED, false);