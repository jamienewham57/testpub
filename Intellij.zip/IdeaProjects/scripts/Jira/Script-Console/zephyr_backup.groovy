import com.atlassian.jira.component.ComponentAccessor
import groovy.json.JsonOutput
import groovy.sql.Sql
import groovy.transform.Field
import java.sql.Connection
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface
import org.apache.log4j.Logger
import org.apache.log4j.Level

// Creates a backup of Zephyr data to <JIRA_HOME>/zephyr_backup_yyyy-MM-dd_HH-mm.json
// <JIRA_HOME> is LOCAL_HOME on standalone and SHARED_HOME on Data Center
// Copy the backup file to the target system LOCAL_HOME or SHARED_HOME

def log = Logger.getLogger("com.valiantys.ZephyrExporter")
log.setLevel(Level.DEBUG)

@Field DelegatorInterface delegator = ComponentAccessor.getComponent(DelegatorInterface)
@Field Connection conn = ConnectionFactory.getConnection(delegator.getGroupHelperName("default"));
@Field Sql sql = new Sql(conn)

def doQuery(String qry) {
    def columns = []
    def getColumnNames = { meta ->
        (1..meta.columnCount).each {
            columns.add(meta.getColumnLabel(it))
        }
    }

    def resultList = []
    sql.eachRow(qry, getColumnNames) { row ->        
        def entry = [:]
        columns.each { col ->
            entry[col] = row[col]
        }
        resultList.add(entry)
    }
    resultList
}

try {
    def result = [:]
    
    result['AO_7DEABF_TESTSTEP'] = doQuery """
        SELECT step.*, concat(p.pkey, '-', ji.issuenum) as issue_key
        FROM AO_7DEABF_TESTSTEP step
        JOIN jiraissue ji ON ji.id = step.issue_id 
        JOIN project p ON p.id = ji.project
    """
    
    result['AO_7DEABF_CYCLE'] = doQuery """
        SELECT c.*, p.pkey, pv.vname
        FROM AO_7DEABF_CYCLE c
        JOIN project p ON p.id = c.PROJECT_ID
        LEFT OUTER JOIN projectversion pv ON pv.project = p.id AND pv.id = c.VERSION_ID 
    """
    
    result['AO_7DEABF_SCHEDULE'] = doQuery """
        SELECT s.*, concat(p.pkey, '-', ji.issuenum) as issue_key, p.pkey, pv.vname
        FROM AO_7DEABF_SCHEDULE s
        JOIN jiraissue ji ON ji.id = s.ISSUE_ID
        JOIN project p ON p.id = s.PROJECT_ID
        LEFT OUTER JOIN projectversion pv ON pv.project = p.id AND pv.id = s.VERSION_ID
    """
    
    result['AO_7DEABF_STEP_RESULT'] = doQuery """
        SELECT sr.*, p.pkey
        FROM AO_7DEABF_STEP_RESULT sr
        JOIN project p ON p.id = sr.PROJECT_ID
    """

    result['AO_7DEABF_STEP_DEFECT'] = doQuery """
        SELECT sd.*, concat(p.pkey, '-', ji.issuenum) as issue_key
        FROM AO_7DEABF_STEP_DEFECT sd
        JOIN jiraissue ji ON ji.id = sd.issue_id 
        JOIN project p ON p.id = ji.project
    """

    result['AO_7DEABF_SCHEDULE_DEFECT'] = doQuery """
        SELECT sd.*, concat(p.pkey, '-', ji.issuenum) as issue_key
        FROM AO_7DEABF_SCHEDULE_DEFECT sd
        JOIN jiraissue ji ON ji.id = sd.issue_id 
        JOIN project p ON p.id = ji.project
    """
    
    def backupFileName = "zephyr_backup_${new Date().format('yyyy-MM-dd_HH-mm')}.json"
    def backup = new File(ComponentAccessor.getComponent(com.atlassian.jira.config.util.JiraHome).home, backupFileName)
    backup.write JsonOutput.toJson(result)
    log.debug "=== Zephyr export to file: ${backupFileName} complete!"
} finally {
    sql.close()
}
