import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.ModifiedValue
import org.apache.log4j.Category

Category log = Category.getInstance("com.onresolve.jira.groovy")
log.setLevel(org.apache.log4j.Level.DEBUG)

//pour les test
IssueManager issueMgr = ComponentAccessor.getIssueManager()
def issue = issueMgr.getIssueObject('RUNAPP1-147')

CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
CustomField cfReflexApp = customFieldManager.getCustomFieldObject((long) 10305)
CustomField cfCodeBu = customFieldManager.getCustomFieldObject((long) 10419)
CustomField cfNiveauService = customFieldManager.getCustomFieldObject((long) 10422)
def cfReflexAppValue = new XmlSlurper().parseText(issue.getCustomFieldValue(cfReflexApp).toString())


log.debug "Nfeed Value = " + cfReflexAppValue


def soapRequest = """<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:app="http://reflex.inetpsa.com/WCFServices/ApplicationRefAppli" xmlns:psa="http://schemas.datacontract.org/2004/07/Psa.Pv3.WCFServices.ApplicationRefAppli">
   <soapenv:Header/>
   <soapenv:Body>
      <app:ConsulterApplication>
         <!--Optional:-->
         <app:request>
            <!--Optional:-->
            <psa:CodeApp>"""+cfReflexAppValue+"""</psa:CodeApp>
            <!--Optional:-->
            <psa:UserId>?</psa:UserId>
         </app:request>
      </app:ConsulterApplication>
   </soapenv:Body>
</soapenv:Envelope>"""


try {
    def soapUrl = new URL("http://reflex.inetpsa.com/WCFSERVICES/Application/ApplicationRefAppli.svc")
    HttpURLConnection connection = (HttpURLConnection) soapUrl.openConnection();
	
	//Attention : Il faut utilise des simples quotes
    connection.setRequestProperty('Content-Type','text/xml')
    connection.setRequestProperty('SOAPAction','http://reflex.inetpsa.com/WCFServices/ApplicationRefAppli/IApplicationRefAppli/ConsulterApplication')
    connection.doOutput = true

	Writer writer = new OutputStreamWriter(connection.outputStream)
    writer.write(soapRequest)
    writer.flush()
    writer.close()


	connection.connect()

    def soapResponse = connection.content.text
    def Envelope = new XmlSlurper().parseText(soapResponse)
    String codeBu = Envelope.Body.ConsulterApplicationResponse.ConsulterApplicationResult.AppBasePlusComplet._appBase._appInfo._codeBU.toString()
    String niveauService = Envelope.Body.ConsulterApplicationResponse.ConsulterApplicationResult.AppBasePlusComplet._appBase._appIndicateurs._indNiveauService.toString()

	log.debug(codeBu)
	log.debug(niveauService)

    MutableIssue mutableIssue = issue
    def changeHolder = new DefaultIssueChangeHolder();
    cfCodeBu.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(cfCodeBu), codeBu),changeHolder)
    cfNiveauService.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(cfNiveauService), niveauService),changeHolder)
    

} catch (Exception e) {
    log.error("Erreur lors de la definition du snapshot", e)
    log.error "  issue id = " + issue.getKey()
    log.error "  soapRequest = " + soapRequest
   
}


