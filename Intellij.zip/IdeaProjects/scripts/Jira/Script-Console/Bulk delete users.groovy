import com.atlassian.jira.bc.security.login.LoginService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.util.UserManager
import com.atlassian.jira.user.util.UserUtil
import java.util.List;
import java.util.ArrayList;
  
def result = ""
  
UserManager userManager = ComponentAccessor.userManager
UserUtil userUtil = ComponentAccessor.userUtil
LoginService loginService = ComponentAccessor.getComponent(LoginService)
  
def myUser = ComponentAccessor.jiraAuthenticationContext?.getUser()
  
if (myUser) {
    List<String> userList = new ArrayList<String>()
    userList.add("christian.heissing");
userList.add("francis@idalko.com");
userList.add("erlm");
userList.add("cgamache");
userList.add("mcosta");
userList.add("johan.santamaria");
userList.add("buhao75");
userList.add("golddluk");
userList.add("dmitryn");
userList.add("ict-serveradmin@markem-imaje.com");
userList.add("alexandre.mur@valiantys.com");
userList.add("nadir.salas");
userList.add("tansuk");
userList.add("henry");
userList.add("alexandre_zieder");
userList.add("hmenzi");
userList.add("higuchi");
userList.add("patrick.renaud");
userList.add("hovingcm");
userList.add("muggie");
userList.add("remi.levesque");
userList.add("safaa");
userList.add("florient.dufay@socgen.com");
userList.add("recordbank");
userList.add("ricardo.calzada");
userList.add("jeri@stibo.com");
userList.add("vikaswebnet");
userList.add("pocket");
 
 
    for(String username : userList)
    {
    com.atlassian.jira.user.ApplicationUser user = userUtil.getUserByKey(username)
        if(user != null) {
            out.println("deleting user : " + user.username);
            if (userUtil.getNumberOfAssignedIssuesIgnoreSecurity(myUser,user)) {
                result += "User $user could not be removed because there are assigned issues!\r\n"
            } else if (userUtil.getNumberOfReportedIssuesIgnoreSecurity(myUser,user)) {
                result += "User $user could not be removed because there are reported issues!\r\n"
            } else if (userUtil.getComponentsUserLeads(user)) {
                result += "User $user could not be removed because he leads a component!\r\n"
            } else {
                userUtil.removeUser(myUser,user)
                result += "User $user removed.\r\n"
            }
        }
    }
}
result