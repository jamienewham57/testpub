import com.atlassian.crowd.embedded.api.Group
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.util.UserManager
import com.atlassian.jira.user.ApplicationUser
 
import org.apache.log4j.Logger
import org.apache.log4j.Level
import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.stream.Stream
 
   
def log = Logger.getLogger("com.valiantys.scriptrunner")
log.setLevel(Level.INFO)
 
Path file = Paths.get("/atlassian/jira/data/import/import_us_users.csv")
Stream<String> lines = Files.lines(file)
 
def groupManager = ComponentAccessor.getGroupManager()
def userManager = ComponentAccessor.getUserManager()
String groupName = "";
Group currentGroup;
lines.forEach(
{ 
    String currentGroupName = it.split(";")[0];
    String currentUserName = it.split(";")[1];
    log.info("Trying to add user ${currentUserName} to group ${currentGroupName}")
    if (currentGroupName != groupName) {
        currentGroup = groupManager.getGroup(currentGroupName);
        groupName = currentGroupName;
    }
    if (currentGroup != null) {
        ApplicationUser currentUser = userManager.getUserByName(currentUserName);
        if (currentUser != null) {
            groupManager.addUserToGroup(currentUser, currentGroup)
        }
    }
})
lines.close()
log.info("===== Ending script")