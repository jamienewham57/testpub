import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.config.util.JiraHome
import groovy.json.*
import groovy.sql.Sql
import groovy.transform.Field
import java.sql.Connection
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface
import org.apache.log4j.Logger
import org.apache.log4j.Level

// The backup file created by the zephyr_backup.groovy script should be copied to the 
// LOCAL_HOME or SHARED_HOME folder before running this script.
// Change the variable below to reflect the correct backup file.

// CHANGE ME!!!
def BACKUP_FILE = 'zephyr_backup_yyyy-MM-dd_HH-mm.json'

@Field Logger log = Logger.getLogger("com.valiantys.ZephyrImporter")
log.setLevel(Level.DEBUG)

@Field DelegatorInterface delegator = ComponentAccessor.getComponent(DelegatorInterface)
@Field Connection conn = ConnectionFactory.getConnection(delegator.getGroupHelperName("default"));
@Field Sql sql = new Sql(conn)

// retrieve the specified backup file
def restoreFile = ComponentAccessor.getComponent(JiraHome).home.listFiles().find { it.name.equals(BACKUP_FILE) }
if (!restoreFile || !restoreFile.exists()) {
    def msg = "Cannot find Zephyr backup file!"
    log.debug msg
    return msg
}

def restoreData = new JsonSlurper().parse(restoreFile)
def issueManager = ComponentAccessor.issueManager
def projectManager = ComponentAccessor.projectManager

// function to insert a row of data into the table
// this function ignors the ID column during insert and 
// returns the new primary key in the NEW_ID field
def doInsert(table, row) {
    // get all columns except for original ID column
    def columns = row.keySet().findAll { it != 'ID' }
    def values = columns.collect { (row[it] instanceof String) ? "'${row[it].replaceAll("'", "''")}'" : row[it] }

    def qry = "INSERT INTO ${table} (${columns.join(',')}) VALUES (${values.join(',')})".toString()
    def keys = sql.executeInsert(qry)
    row['NEW_ID'] = keys[0][0]
}

// import tables in the following order:
// 1. AO_7DEABF_TESTSTEP; use issue_key to lookup and replace ISSUE_ID
// 2. AO_7DEABF_CYCLE; use pkey and vname to lookup and replace PROJECT_ID and VERSION_ID
// 3. AO_7DEABF_SCHEDULE; use issue_key, pkey and vname to lookup and replace ISSUE_ID, PROJECT_ID and VERSION_ID. Replace CYCLE_ID with NEW_ID from AO_7DEABF_CYCLE
// 4. AO_7DEABF_STEP_RESULT; use pkey to lookup and replace PROJECT_ID. Replace SCHEDULE_ID with NEW_ID from AO_7DEABF_SCHEDULE and STEP_ID with NEW_ID from AO_7DEABF_TESTSTEP
// 5. AO_7DEABF_TEST_DEFECT and AO_7DEABF_SCHEDULE_DEFECT; use issue_key to lookup DEFECT_ID. Replace foreign keys with relevant table's NEW_ID

try {
    restoreData['AO_7DEABF_TESTSTEP'].each { row ->
        // lookup issue
        def issue = issueManager.getIssueObject(row.issue_key as String)
        if (issue) {
            // update fields with correct values
            row.ISSUE_ID = issue.id
            row.remove('issue_key')
            doInsert('AO_7DEABF_TESTSTEP', row)
        }
    }
    log.debug "=== Zephyr import: completed import of AO_7DEABF_TESTSTEP"

    restoreData['AO_7DEABF_CYCLE'].each { row ->
        // lookup project
        def project = projectManager.getProjectObjByKey(row.pkey as String)
        if (project) {
            def versionId = -1
            if (row.VERSION_ID != -1)
                versionId = project.versions.find { it.name == row.vname }?.id

            // update fields with correct values
            row.PROJECT_ID = project.id
            row.VERSION_ID = versionId
            row.remove('pkey')
            row.remove('vname')
            doInsert('AO_7DEABF_CYCLE', row)
        }
    }
    log.debug "=== Zephyr import: completed import of AO_7DEABF_CYCLE"

    restoreData['AO_7DEABF_SCHEDULE'].each { row ->
        // lookup issue and project
        def issue = issueManager.getIssueObject(row.issue_key as String)
        def project = projectManager.getProjectObjByKey(row.pkey as String)
        if (issue && project) {
            def versionId = -1
            if (row.VERSION_ID != -1)
                versionId = project.versions.find { it.name == row.vname }?.id
            def cycle = restoreData['AO_7DEABF_CYCLE'].find { it.ID == row.CYCLE_ID }

            // updated fields with correct values
            row.ISSUE_ID = issue.id
            row.PROJECT_ID = project.id
            row.VERSION_ID = versionId
            row.CYCLE_ID = cycle.NEW_ID
            row.remove('issue_key')
            row.remove('pkey')
            row.remove('vname')
            doInsert('AO_7DEABF_SCHEDULE', row)
        }
    }
    log.debug "=== Zephyr import: completed import of AO_7DEABF_SCHEDULE"

    restoreData['AO_7DEABF_STEP_RESULT'].each { row ->
        // lookup project
        def project = projectManager.getProjectObjByKey(row.pkey as String)
        if (project) {
            def schedule = restoreData['AO_7DEABF_SCHEDULE'].find { it.ID == row.SCHEDULE_ID }
            def testStep = restoreData['AO_7DEABF_TESTSTEP'].find { it.ID == row.STEP_ID }

            // updated fields with correct values
            row.PROJECT_ID = project.id
            row.SCHEDULE_ID = schedule.NEW_ID
            row.STEP_ID = testStep.NEW_ID
            row.remove('pkey')
            doInsert('AO_7DEABF_STEP_RESULT', row)
        }
    }
    log.debug "=== Zephyr import: completed import of AO_7DEABF_STEP_RESULT"

    restoreData['AO_7DEABF_TEST_DEFECT'].each { row ->
        // lookup issue
        def issue = issueManager.getIssueObject(row.issue_key as String)
        if (issue) {
            def schedule = restoreData['AO_7DEABF_SCHEDULE'].find { it.ID == row.SCHEDULE_ID }
            def testStep = restoreData['AO_7DEABF_TESTSTEP'].find { it.ID == row.STEP_ID }
            def stepResult = restoreData['AO_7DEABF_STEP_RESULT'].find { it.ID == row.STEP_RESULT_ID }

            // update fields with correct values
            row.DEFECT_ID = issue.id
            row.SCHEDULE_ID = schedule.NEW_ID
            row.STEP_ID = testStep.NEW_ID
            row.STEP_RESULT_ID = stepResult.NEW_ID
            row.remove('issue_key')
            doInsert('AO_7DEABF_TEST_DEFECT', row)
        }
    }
    log.debug "=== Zephyr import: completed import of AO_7DEABF_TEST_DEFECT"
    
    restoreData['AO_7DEABF_SCHEDULE_DEFECT'].each { row ->
        // lookup issue
        def issue = issueManager.getIssueObject(row.issue_key as String)
        if (issue) {
            def schedule = restoreData['AO_7DEABF_SCHEDULE'].find { it.ID == row.SCHEDULE_ID }

            // update fields with correct values
            row.DEFECT_ID = issue.id
            row.SCHEDULE_ID = schedule.NEW_ID
            row.remove('issue_key')
            doInsert('AO_7DEABF_SCHEDULE_DEFECT', row)
        }
    }
    log.debug "=== Zephyr import: completed import of AO_7DEABF_SCHEDULE_DEFECT"

    log.debug "=== Zephyr import from ${BACKUP_FILE} complete!"
} finally {
    sql.close()
}
