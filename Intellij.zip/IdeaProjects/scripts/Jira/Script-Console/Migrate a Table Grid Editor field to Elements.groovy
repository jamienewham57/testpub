import com.atlassian.jira.component.ComponentAccessor
import groovy.sql.Sql
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface
import com.atlassian.jira.issue.Issue
import java.sql.Connection
import com.atlassian.jira.issue.IssueManager
import com.atlassian.plugin.PluginAccessor
import com.atlassian.jira.user.ApplicationUser
 
PluginAccessor pluginAccessor = ComponentAccessor.getPluginAccessor()
Class panelContentServiceClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.content.PanelContentService")
Class panelRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.PanelRef")
Class issueRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.IssueRef")
Class attributeRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.AttributeRef")
Class writeOptionsClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.content.WriteOptions")
def panelContentService = ComponentAccessor.getOSGiComponentInstanceOfType(panelContentServiceClass)
 
def issueManager = ComponentAccessor.getIssueManager()
def delegator = (DelegatorInterface) ComponentAccessor.getComponent(DelegatorInterface)
String helperName = delegator.getGroupHelperName("default")
Connection conn = ConnectionFactory.getConnection(helperName)
Sql sql = new Sql(conn)
  
//SQL Query - differs for each database
def sqlStmt = "select * from invoices_c17211"
def row = sql.rows(sqlStmt)
String issueId = ""
String title = ""
String numberOfDays = ""
String expenses = ""
String amount = ""
String currency = ""
String invoiceAttachment = ""
String status = ""

List<Invoice> invoices = new ArrayList<Invoice>()
Map<String,List<Invoice>> invoicesMap = new HashMap<String,List<Invoice>>()
sql.rows(sqlStmt).findAll {row}.each{
    Invoice invoice = new Invoice()
    invoice.issueKey = issueManager.getIssueObject(it.issueId)
    invoice.title = it.title
    invoice.numberOfDays = it.days
    invoice.expenses = it.expenses
    invoice.amount = it.amount
    invoice.currency = it.currency_name
    invoice.invoiceAttachment = it.invoice
    invoice.status = it.invoice_status_name
    
    if(invoice.title != null) {
        if(invoicesMap.containsKey(invoice.issueKey)) {
            List<Invoice> invoicesList = new ArrayList<Invoice>()
            invoicesList.addAll(invoicesMap.get(invoice.issueKey))
            invoicesList.add(invoice)
            invoicesMap.remove(invoice.issueKey)
            invoicesMap.put(invoice.issueKey,invoicesList)
        } else {
            invoicesMap.put(invoice.issueKey,[invoice])
        }
    }
}


def panelRef = panelRefClass.byName("Invoices history")
for(def entrySet : invoicesMap.entrySet()) {
    def key = entrySet.key
    def value = entrySet.value
    
    def issue = issueManager.getIssueObject(key)
    if(issue != null) {
        def issueRef = issueRefClass.byId(issue.id)
        def builder = panelContentService.createPanelBuilder(issueRef, panelRef)
      
        value.each{ invoice ->
            Double numberOfDaysDouble = 0.0
            if(invoice.numberOfDays != null) {
            	numberOfDaysDouble = Double.parseDouble(invoice.numberOfDays)
            }
            Double expensesDouble = 0.0
            if(invoice.expenses != null) {
                expensesDouble = Double.parseDouble(invoice.expenses)
            }
            Double amountDouble = 0.0
            if(invoice.amount != null) {
                amountDouble = Double.parseDouble(invoice.amount)
            }
            Long attachmentLong
            if(invoice.invoiceAttachment != null && !invoice.invoiceAttachment.equals("")) {
            	attachmentLong = Long.parseLong(invoice.invoiceAttachment)
            }
            
            if(attachmentLong != null) {
                builder.panelItem().textValue(attributeRefClass.byName("Title"), invoice.title)
                                    .numberValue(attributeRefClass.byName("Number of days"), numberOfDaysDouble)
                                    .numberValue(attributeRefClass.byName("Expenses"), expensesDouble)
                                    .numberValue(attributeRefClass.byName("Amount"), amountDouble)
                                    .optionIds(attributeRefClass.byName("Currency"), [getCurrency(invoice.currency)])
                                    .attachment(attributeRefClass.byName("Invoice"), attachmentLong)
                                    .optionIds(attributeRefClass.byName("Status"), [getStatus(invoice.status)])
            } else {
                builder.panelItem().textValue(attributeRefClass.byName("Title"), invoice.title)
                                    .numberValue(attributeRefClass.byName("Number of days"), numberOfDaysDouble)
                                    .numberValue(attributeRefClass.byName("Expenses"), expensesDouble)
                                    .numberValue(attributeRefClass.byName("Amount"), amountDouble)
                                    .optionIds(attributeRefClass.byName("Currency"), [getCurrency(invoice.currency)])
                                    .optionIds(attributeRefClass.byName("Status"), [getStatus(invoice.status)])
            }
		}

        def writeOptions = writeOptionsClass.newInstance()
        panelContentService.setPanelContent(issueRef, panelRef, builder.build(), writeOptions.withOverwrite(true))
    }
}



public class Invoice {
    public String issueKey
    public String title
    public String numberOfDays
    public String expenses
    public String amount
    public String currency
    public String invoiceAttachment
    public String status
    
    public String toString() {
        return issueKey + " | " + title + " | " + numberOfDays + " | " + expenses + " | " + amount + " | " + currency + " | " + invoiceAttachment + " | " + status
    }
}

public String getCurrency(String currencyName) {
    switch(currencyName) {
        case "Euro": return "ad9wg5v41"
        case "Pound Sterling" : return "fmlqr7f4c"
        case "US Dollar" : return "c6318r31q"
        case "Franc Suisse" : return "ay6kb7i1e"
        case "Canadian Dollar" : return "9c02u6kbr"
    }
}

public String getStatus(String statusName) {
    switch(statusName) {
        case "Created" : return "n0bpfu8ti"
        case "Waiting for payment" : return "zoiopjs6o"
        case "Paid" : return "2781lqaog"
    }
}