import org.apache.log4j.Category
 
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG);
 
def sourceFile = new File('/atlassian/jira/data/tmp/input-users.csv').getText('UTF-8')
def targetFile = new File('/atlassian/jira/data/tmp/create-users.sh')
 
def userMap
 
targetFile.append("#!/bin/sh -e \n")
 
for (String userLine : sourceFile.readLines()) {
userMap = userLine.split(";")
log.debug "${userMap[0]} ..."
targetFile.append("curl -D- -k -u valiantys:XXX -X POST -H \"Content-Type: application/json\" --data '{\"name\":\""+userMap[1]+"\", \"emailAddress\":\""+userMap[1]+"\", \"displayName\":\""+userMap[0]+"\" }' \"https://myjira.valiantys.net/rest/api/2/user\" \n")
}