import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.crowd.embedded.api.Group
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.user.util.UserManager
import com.atlassian.jira.security.groups.GroupManager
import com.atlassian.jira.issue.subscription.SubscriptionManager
import org.apache.log4j.Category
 
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG);

log.debug "Start : subscribeToFilter";

//Manager
UserManager userManager = ComponentAccessor.getUserManager();
GroupManager groupManager = ComponentAccessor.getGroupManager();
SubscriptionManager subscriptionManager = ComponentAccessor.getSubscriptionManager();

//Constants
String GROUP_NAME = "jira-software-users";
String CRON_EXPRESSION = "0 0 22 * * ?";
long FILTER_ID = 10103;

//Treatment
Group groupObject = groupManager.getGroup(GROUP_NAME);
Collection <ApplicationUser> usersInGroup = groupManager.getUsersInGroup(groupObject);

int numberOfSubscription = 0;

for(ApplicationUser appUser : usersInGroup) {
	boolean userIsAlreadySubscriber = subscriptionManager.hasSubscription(appUser, FILTER_ID);
    log.debug "Check if "+appUser+" is already subscriber ? :"+userIsAlreadySubscriber;
    if (!userIsAlreadySubscriber){
        subscriptionManager.createSubscription(appUser, FILTER_ID, "", CRON_EXPRESSION, false);
        numberOfSubscription ++;
    }
}

log.debug "End : subscribeToFilter";

return numberOfSubscription;