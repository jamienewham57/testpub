import com.atlassian.crowd.embedded.api.User
import com.atlassian.crowd.embedded.impl.ImmutableUser
import com.atlassian.jira.bc.user.UserService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.util.UserManager
import com.atlassian.jira.bc.group.search.GroupPickerSearchService
import org.apache.log4j.Logger
import org.apache.log4j.Level
import java.io.File
   
def log = Logger.getLogger("com.valiantys.scriptrunner")
log.setLevel(Level.INFO)
 
File temp = File.createTempFile("export",".csv");
def groupManager = ComponentAccessor.getGroupManager()
 
GroupPickerSearchService groupService = ComponentAccessor.getComponent(GroupPickerSearchService.class)
 
temp.append("group;user\n")
groupService.findGroups("").each { group ->
    groupManager.getUsersInGroup(group.getName()).each {
        user -> temp.append(group.getName() + ";" + user.getName() + "\n")
    }
}
 
log.info(temp.getAbsolutePath())