import com.atlassian.jira.bc.JiraServiceContextImpl
import com.atlassian.jira.bc.filter.SearchRequestService
import com.atlassian.jira.issue.search.SearchRequest
import com.atlassian.jira.user.util.UserManager
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.component.ComponentAccessor
import java.util.Collection
import org.apache.log4j.Category
import com.atlassian.jira.bc.JiraServiceContext
import com.atlassian.jira.security.JiraAuthenticationContext
 
Category log = Category.getInstance("com.onresolve.jira.groovy")
log.setLevel(org.apache.log4j.Level.DEBUG)
Collection<SearchRequest> filtres
UserManager userManager = ComponentAccessor.getUserManager()
def searchRequestService = ComponentAccessor.getComponent(SearchRequestService.class)
  
//Put users' usernames between quotes: ID_ancien_proprio for the previous owner / ID_nouveau_proprio for the desired owner
String ID_ancien_proprio = "E0991677"
String ID_nouveau_proprio = "G1767650"
  
ApplicationUser ancien_proprio = userManager.getUserByName(ID_ancien_proprio)
ApplicationUser nouveau_proprio = userManager.getUserByName(ID_nouveau_proprio)
  
JiraAuthenticationContext jiraAuthenticationContext = ComponentAccessor.getJiraAuthenticationContext();
  
ApplicationUser userLogged = jiraAuthenticationContext.getLoggedInUser();
  
JiraServiceContext serviceCtx = new JiraServiceContextImpl(ancien_proprio);
  
  
filtres = searchRequestService.getOwnedFilters(ancien_proprio)
for (SearchRequest chgt_proprio : filtres){
  
    chgt_proprio.setOwner(nouveau_proprio)
    //nouveau_proprio must have admin permissions
    searchRequestService.updateFilterOwner(serviceCtx, nouveau_proprio, chgt_proprio)
    log.debug (chgt_proprio.toString())
  
}
 
 
return