import com.valiantys.software.elements.api.content.*;
import com.valiantys.software.elements.api.model.*;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.plugin.PluginAccessor;

PluginAccessor pluginAccessor = ComponentAccessor.getPluginAccessor();
pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.ElementsException");

// All Class requirements
Class panelContentServiceClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.content.PanelContentService");
Class panelRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.PanelRef");
Class issueRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.IssueRef");
Class attributeRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.AttributeRef");

Class selectOptionClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.SelectOption");
Class SelectListAttributeContent = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.SelectListAttributeContent");
Class EntityAttributeContent = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.SelectListAttributeContent");

def panelContentService = ComponentAccessor.getOSGiComponentInstanceOfType(panelContentServiceClass);

// Define Elements panel
def panelContent;
try {
    panelContent = panelContentService.getPanel(issueRefClass.byId(issue.getId()), panelRefClass.byName("Expenses"), new ReadOptions().withEntities());
} catch (Exception e) {
    return 'no panel found';
}

def panelItems = panelContent.getPanelItems();

if (panelItems.size() == 0) {
    return "No elements of type 'Food'";
} else {
    def sumOfFoodAmount = 0;
    for (def element : panelItems) {

        // 'Type' is a attribute of type Select list (single)
        def selectAttrContent = element.getAttributeContent(attributeRefClass.byName("Type"));

        // Get the id
        def selectListValueId = selectAttrContent?.getValue()?.get(0);

        //Get list of available options e.g : Food, Travel, Hotel...
        def entitySelectListOptions = selectAttrContent?.getEntity();

        // Run through options and compare their name and id
        for (def option : entitySelectListOptions) {
            if (option.getName() == "Food" && option.getId() == selectListValueId) {
                def foodAmount = element.getAttributeContent(attributeRefClass.byName("Amount"))?.getValue();
                sumOfFoodAmount = sumOfFoodAmount + foodAmount;
            }
        }
    }
    return sumOfFoodAmount;
}
