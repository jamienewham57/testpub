import com.atlassian.plugin.PluginAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import java.util.HashMap
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.customfields.option.Option
import com.atlassian.jira.issue.customfields.view.CustomFieldParams
import com.atlassian.jira.issue.customfields.option.LazyLoadedOption
import com.atlassian.jira.issue.customfields.impl.CascadingSelectCFType
import com.atlassian.crowd.embedded.api.Group
import com.atlassian.jira.security.groups.GroupManager
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.link.IssueLinkImpl
    
enableCache = {-> false}
    
PluginAccessor pluginAccessor = ComponentAccessor.getPluginAccessor()
Class dataPanelScoringServiceClass = pluginAccessor.getClassLoader().findClass("com.valiantys.jira.plugins.exocet.service.DataPanelScoringService")
 
def dataPanelScoringService = ComponentAccessor.getOSGiComponentInstanceOfType(dataPanelScoringServiceClass)
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
GroupManager groupManager = ComponentAccessor.getComponent(GroupManager.class)
def issueLinkManager = ComponentAccessor.getIssueLinkManager()
     
def scoring = 0
 
issueLinkManager.getOutwardLinks(issue.id).each {issueLink ->  
    def linkedissuetype = issueLink.getDestinationObject().getIssueType().getName()
    def linkedOriginalEstimate = issueLink.getDestinationObject().getOriginalEstimate()
    if (issueLink.issueLinkType.id == 10300){
        if (linkedissuetype =~ /.Estimate*/ ){
            linkedOriginalEstimate = linkedOriginalEstimate == null?0:linkedOriginalEstimate
            scoring = scoring + linkedOriginalEstimate
            }
        }
    }
         
return scoring