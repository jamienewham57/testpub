import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.changehistory.ChangeHistoryManager
import com.atlassian.jira.issue.history.ChangeItemBean
 
enableCache = {-> false}
String fieldname1 = 'FieldName1'
String fieldname2 = 'FieldName2'
  
ChangeHistoryManager changeHistoryManager = ComponentAccessor.getChangeHistoryManager()
List<ChangeItemBean> changeItems
changeItems = changeHistoryManager.getChangeItemsForField(issue, fieldname1)
List<ChangeItemBean> changeItems1
changeItems1 = changeHistoryManager.getChangeItemsForField(issue, fieldname2)
if (changeItems.size()>0) {
changeItems.find{it.toString == "FIELDVALUE"}?.getCreated()
}else if (changeItems1.size()>0) {
changeItems1.find{it.toString == "FIELDVALUE"}?.getCreated()
}