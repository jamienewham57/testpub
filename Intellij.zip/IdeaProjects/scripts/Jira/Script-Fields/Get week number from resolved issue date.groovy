import java.sql.Timestamp
import com.atlassian.core.util.DateUtils
 
def resdate = issue.getResolutionDate().format("DD").toInteger()
def cal = resdate / 7
def ans = cal.toDouble().round(0)
return ans