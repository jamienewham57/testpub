/*
Context : custom fields "Niveau demandeur (valeur AD)" and "Niveau bénéficiaire(valeur AD)" retrieves an attribute from the Active Directory that can be either 1 (VIP level), 2 (semi-VIP level) or null (regular). We use the highest one.
*/
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.jql.parser.JqlQueryParser
 
 
def changeHolder = new DefaultIssueChangeHolder()
final id=issue.getId()
def componentManager = ComponentManager.getInstance()
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
final searchService = ComponentAccessor.getComponentOfType(SearchService.class)
def jqlQueryParser = ComponentManager.getComponentInstanceOfType(JqlQueryParser.class)
 
def niveauredquery = "('Niveau demandeur (valeur AD)' = 1 or 'Niveau bénéficiaire (valeur AD)' = 1)"
def niveauorangequery = "('Niveau demandeur (valeur AD)' = 2 or 'Niveau bénéficiaire (valeur AD)' = 2)"
def redquery = jqlQueryParser.parseQuery("issue = "+ id + " AND " + niveauredquery)
def orangequery = jqlQueryParser.parseQuery("issue = "+ id + " AND " + niveauorangequery)
 
def red   = searchService.searchCount(ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser(), redquery)
def orange   = searchService.searchCount(ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser(), orangequery)
def html_value
def non_html_value
if (red)
{
    html_value="<span class=\"aui-lozenge aui-lozenge-error\">VIP</span>"
}
else if (orange)
{
    html_value="<span class=\"aui-lozenge aui-lozenge-current\">Semi-VIP</span>"
}
else
{
    html_value="<span class=\"aui-lozenge aui-lozenge-success\">Classique</span>"
}