import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.customfields.option.Option
import com.atlassian.jira.ManagerFactory
 
 
def reporter = issue.getReporterId()
def baseurl = ComponentManager.getInstance().getApplicationProperties().getString("jira.baseurl")
def url = baseurl.toString() + "/issues/?jql=reporter%20%3D%20" + reporter.toString() + "%20ORDER%20BY%20created%20DESC"
 
def writer = "<a target=\"_blank\" href=\"" + url + "\">Link to customer other requests</a>"
    return writer

