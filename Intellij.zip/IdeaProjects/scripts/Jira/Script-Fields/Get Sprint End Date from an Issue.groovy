// Version: 1.0
// Last Change 2017/03/10 18:09
// reto.gehring@valiantys.com
// Customer requirement: As the due date is not set trough the sprint he would like to see the sprint end date
// in the issue navigator to sort after or ven on the issue it self. 
 
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
  
import com.atlassian.greenhopper.service.sprint.Sprint
import com.atlassian.greenhopper.service.sprint.SprintManager
  
// log.setLevel(org.apache.log4j.Level.DEBUG)
 
Issue issue  = issue
 
// Create JAVA Date Object
Date activeSprintEndDate = null
  
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def sprintCf = customFieldManager.getCustomFieldObjectByName("Sprint")
assert sprintCf
//Get All Sprints attached to the current issue
def sprints = issue.getCustomFieldValue(sprintCf) as List<Sprint>
  
//if any sprint
if (sprints) {
    //for each sprint
    sprints.each {
        sprint ->
        //if sprint is active
         if(sprint.isActive()) {
                                    //get sprint end date
                                    activeSprintEndDate = sprint.getEndDate().toDate()
                                      
                               }
    }
}
  
return activeSprintEndDate