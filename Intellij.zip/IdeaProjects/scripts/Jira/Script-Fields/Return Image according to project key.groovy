def val = issue.getProject().key
def result = "";//"unknown.jpg"
def alt= "";
switch (val) {
  
case "KEY1":
result = "KEY1.png"
alt = "Project 1"
break
 
case "KEY2":
result = "KEY2.png"
alt = "Project 2"
break
 
default:
return null;
}
return "<img src=\"/images/icons/<your dir name>/"+result+"\" alt=\""+alt+"\"/>"