import com.atlassian.jira.ComponentManager
import com.atlassian.jira.security.groups.GroupManager 
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.ManagerFactory
 
def reporter = issue.getReporter()
GroupManager groupManager = componentManager.getComponentInstanceOfType(GroupManager.class)
   
if (groupManager.isUserInGroup(reporter.name, "Company2"))
{   
    def writer = "<div class=\"aui-message aui-message-error\">" +
    "<p class=\"title\">" +
    "<strong>Reporter doesn't have the correct level</strong>" +   
    "</p>" +
    "<p>Please contact his manager to approve this issue</p>" +
    "</div><!-- .aui-message --> "
    return writer
}
else {
    return null
}