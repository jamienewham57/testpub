import com.atlassian.jira.component.ComponentAccessor

def changeHistoryManager = ComponentAccessor.getChangeHistoryManager()

def changeHistories = changeHistoryManager.getChangeHistories(issue)

for(def changeHistory : changeHistories) {
    if(changeHistory.getChangeItemBeans().find {it.getFrom().equals("10023") && it.getTo().equals("3")} != null) {
    	return changeHistory.getAuthorKey()
    }
    if(changeHistory.getChangeItemBeans().find {it.getFrom().equals("10006") && it.getTo().equals("12429")} != null) {
    	return changeHistory.getAuthorKey()
    }
}
