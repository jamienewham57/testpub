import com.atlassian.jira.component.ComponentAccessor

def customFieldManager = ComponentAccessor.getCustomFieldManager()

def startDateCf = customFieldManager.getCustomFieldObject("customfield_11945")
def endDateCf = customFieldManager.getCustomFieldObject("customfield_11946")

def startDate = issue.getCustomFieldValue(startDateCf)
def endDate = issue.getCustomFieldValue(endDateCf)

if(startDate != null && endDate != null) {
	return ((endDate - startDate)) +1
}