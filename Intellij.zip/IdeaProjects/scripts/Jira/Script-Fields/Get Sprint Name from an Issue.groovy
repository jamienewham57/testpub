import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.greenhopper.service.sprint.Sprint
 
def sprint = ComponentAccessor.getCustomFieldManager().getCustomFieldObjectByName("Sprint")
 
ArrayList<Sprint> list = (ArrayList<Sprint>) sprint.getValue(issue)
 
if(list != null) {
Iterator<Sprint> it = list.iterator()
while(it.hasNext()) {
Sprint sprintname = it.next()
return sprintname.getName()
}
}