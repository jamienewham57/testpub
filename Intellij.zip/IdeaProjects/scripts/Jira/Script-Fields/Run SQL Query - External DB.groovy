import groovy.sql.Sql
import java.sql.Driver
import com.atlassian.jira.issue.Issue
  
Issue issue = issue
  
//you jdbc driver
def driver = Class.forName('net.sourceforge.jtds.jdbc.Driver').newInstance() as Driver 
def props = new Properties()
  
//DB Username + Password
props.setProperty("user", "jira")
props.setProperty("password", "jira")
  
//URL - remember to add useLOBs=false for MSSQL Databases otherwise you won't get result as String
def conn = driver.connect("jdbc:jtds:sqlserver://localhost:1473/jiradb;useLOBs=false", props)
def sql = new Sql(conn)
  
//SQL Query - differs for each database
def sqlStmt = """
select * from project
"""
 
def row = sql.rows(sqlStmt)
String value = ""
sql.rows(sqlStmt).findAll {row}.each{
    value += ${it.pname}"
}
return value