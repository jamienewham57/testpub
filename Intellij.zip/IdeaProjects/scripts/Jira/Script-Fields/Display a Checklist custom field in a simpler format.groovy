// Display a Checklist custom field in a simpler format that can be included inside Confluence's Jira macros for example.

import com.atlassian.jira.component.ComponentAccessor

def customFieldManager = ComponentAccessor.getCustomFieldManager()

def checklistCf1 = customFieldManager.getCustomFieldObject("customfield_13731")
def checklistCf2 = customFieldManager.getCustomFieldObject("customfield_13736")
def checklistCf3 = customFieldManager.getCustomFieldObject("customfield_13732")
def prereqChecklistCf = customFieldManager.getCustomFieldObject("customfield_15630")

def cfValue = null

if(issue.getIssueTypeObject().getName() == "Private training") {
	cfValue = issue.getCustomFieldValue(checklistCf2)
} else if(issue.getIssueTypeObject().getName() == "Public training") {
	cfValue = issue.getCustomFieldValue(checklistCf1)
} else if(issue.getIssueTypeObject().getName() == "Project") {
    cfValue = issue.getCustomFieldValue(prereqChecklistCf)
} else {
    cfValue = issue.getCustomFieldValue(checklistCf3)
}

def ret = "<ul>"

for(def checkbox : cfValue) {
	if(checkbox.isChecked())
		ret += "<li><strike>" + checkbox.name + "</strike></li>"
	else
		ret += "<li>" + checkbox.name + "</li>"
}

return ret+"</ul>"