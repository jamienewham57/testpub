import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.fields.CustomField;
     
        IssueManager issueManager = ComponentAccessor.getIssueManager();
        CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager();
        final CustomField customFieldObject = customFieldManager.getCustomFieldObject("customfield_10404");
             
        if(customFieldObject == null){
            return "Invalid Custom Field";
        }
        double total = 0;
        if (issue != null) {
            final Collection<Issue> subTaskObjects = issue.getSubTaskObjects();
            if(subTaskObjects != null && subTaskObjects.size() != 0){
                String debug = "";
                for (Issue subTaskObject : subTaskObjects) {
                        if (subTaskObject.getIssueType().name.equals("Document")){
                        final Object value = customFieldObject.getValue(subTaskObject);
                        total += Double.parseDouble(value.toString());
                        debug = debug + value.toString() + ", ";
                    }
                }
                return String.format("%.2f%n",total);
            }
            else{
                return "No subtasks";
            }
        }
        return "Internal Error";