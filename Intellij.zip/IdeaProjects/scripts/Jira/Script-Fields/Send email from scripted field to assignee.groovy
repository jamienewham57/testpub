def email = issue.getAssignee().emailAddress
def key = issue.getKey()
def subject = issue.getSummary()
 
def button="<a href='mailto:$email?subject=Re:%20$subject%20($key)'>" +
    "<button class=\"aui-button aui-button-primary\">" +
     "Email" +
    "</button>" +
    "</a>"
return button