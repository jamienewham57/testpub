import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.ComponentManager
enableCache = {-> false}
def changeHistoryManager = ComponentManager.getInstance().getChangeHistoryManager()
def issueChanges = changeHistoryManager.getAllChangeItems(issue)
def userUtil =  ComponentAccessor.getUserUtil()
if (issueChanges?.size()>0) {
user = userUtil.getUserByName(issueChanges.sort(false).last().user)
} else {
    null
}