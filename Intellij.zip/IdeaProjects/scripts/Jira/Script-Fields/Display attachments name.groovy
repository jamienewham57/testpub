import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.config.properties.APKeys
  
def attachments = ComponentAccessor.getAttachmentManager().getAttachments(issue)
def baseUrl = ComponentAccessor.getApplicationProperties().getString(APKeys.JIRA_BASEURL)
  
attachments.collect {
    '<a href="' + baseUrl + '/secure/attachment/'+ it.id +'/'+
        URLEncoder.encode(it.filename, "UTF-8") +'">' + it.filename + '</a>'
}.join("<br>")