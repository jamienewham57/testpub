import com.atlassian.plugin.PluginAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import java.util.HashMap
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.customfields.option.Option
import com.atlassian.jira.issue.customfields.view.CustomFieldParams
import com.atlassian.jira.issue.customfields.option.LazyLoadedOption
import com.atlassian.jira.issue.customfields.impl.CascadingSelectCFType
import com.atlassian.crowd.embedded.api.Group
import com.atlassian.jira.security.groups.GroupManager
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.link.IssueLinkImpl
    
enableCache = {-> false}
    
PluginAccessor pluginAccessor = ComponentAccessor.getPluginAccessor()
Class dataPanelScoringServiceClass = pluginAccessor.getClassLoader().findClass("com.valiantys.jira.plugins.exocet.service.DataPanelScoringService")
def issueproject = issue.getProjectId()
if(issueproject == 12701 || issueproject == 13545|| issueproject == 12702){
def dataPanelScoringService = ComponentAccessor.getOSGiComponentInstanceOfType(dataPanelScoringServiceClass)
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
GroupManager groupManager = ComponentAccessor.getComponent(GroupManager.class)
def issueLinkManager = ComponentAccessor.getIssueLinkManager()
     
def userGroup = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_14704")
def userGroupValue = (List<Group>) issue.getCustomFieldValue(userGroup)
def userGroupName
def userNumber = 0
def upVote = 0
def perc = 0
for(Group group:userGroupValue){
    userGroupName = group.getName()
}
//checking if the group exist
if (groupManager.getGroup(userGroupName)){
        def memberManager = ComponentAccessor.getGroupManager()
        def users = memberManager.getUserNamesInGroup(userGroupName)
        def userManager = ComponentAccessor.getUserUtil()
        users.each {
               userNumber = userNumber+1
             
        }
    issueLinkManager.getOutwardLinks(issue.id).each {issueLink ->  
        def linkedissuetype = issueLink.getDestinationObject().getIssueType().getName()
        if (linkedissuetype == "Up Vote"){
            issueLinkManager.getInwardLinks(issue.id).each {issueLink2 ->  
                
                    if (issueLink2.issueLinkType.id == 11400 ){  
                        upVote = upVote+1
                        
                        }
            }
        }
    }
    if (upVote != 0){
        perc = upVote*100
        perc = perc/Integer.parseInt(userNumber.toString())
        return (Double) perc
        }
    }
}