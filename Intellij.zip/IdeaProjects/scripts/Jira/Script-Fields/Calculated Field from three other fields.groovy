import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def CIDf = customFieldManager.getCustomFieldObject('customfield_10801')
def CEDf = customFieldManager.getCustomFieldObject('customfield_10802')
def CERf = customFieldManager.getCustomFieldObject('customfield_10912')
def Otherf = customFieldManager.getCustomFieldObject('customfield_10913')
  
def CID = issue.getCustomFieldValue(CIDf)
def CED = issue.getCustomFieldValue(CEDf)
def CER = issue.getCustomFieldValue(CERf)
def Other = issue.getCustomFieldValue(Otherf)
 
  
CID = CID == null?0:CID
CED = CED == null?0:CED
CER = CER == null?0:CER
Other = Other == null?0:Other
  
def CIR = 500
CI = CID*CIR
CE = CED*CER
Double total = CE + CI + Other
     
return total