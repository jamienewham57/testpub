import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.plugin.PluginAccessor;

PluginAccessor pluginAccessor = ComponentAccessor.getPluginAccessor();
Class panelContentServiceClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.content.PanelContentService");
Class panelRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.PanelRef");
Class issueRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.IssueRef");
Class attributeRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.AttributeRef");
pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.ElementsException");

def panelContentService = ComponentAccessor.getOSGiComponentInstanceOfType(panelContentServiceClass);
def PANEL_NAME = "Tasks";
def CHECKBOX_ATTRIBUTE = "Done";

// Define Elements panel
def panelContent;
try {
	panelContent = panelContentService.getPanel(issueRefClass.byId(issue.getId()), panelRefClass.byName(PANEL_NAME));
} catch(Exception e) {
    return '';
}
def panelItems = panelContent.getPanelItems();

if(panelItems.size() > 0) {
  def nbElements = panelItems.size();
  def nbElementsChecked = 0;
  for(def element : panelItems) {
      def isChecked = element.getAttributeContent(attributeRefClass.byName(CHECKBOX_ATTRIBUTE))?.getValue();
      if(isChecked) {
        nbElementsChecked += 1;
      }
  }

  def percentageDone = nbElementsChecked / nbElements * 100;
  def progress = "<progress  style=\"vertical-align:middle; max-width: 60%;\" value=\""+percentageDone+"\" min=\"0\" max=\"100\">"+percentageDone+"%</progress>"
  def spanProgression = " <span style=\"color:#999\">"+nbElementsChecked+"/"+nbElements+"</span>";

  return "<div>" + progress + " " + spanProgression + "</div>";
}
