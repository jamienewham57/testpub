import com.atlassian.jira.component.ComponentAccessor
def double nb = 0
items = ComponentAccessor.getChangeHistoryManager().getChangeItemsForField(
issue, "status").findAll({it.getToString() == "Status Name"})?.each{ change ->
     nb++     
}
if (nb != 0) return nb
return null