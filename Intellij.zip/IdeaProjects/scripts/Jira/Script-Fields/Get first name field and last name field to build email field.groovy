import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def nomCF = customFieldManager.getCustomFieldObject('customfield_13000')
def prenomCF = customFieldManager.getCustomFieldObject('customfield_11947')
 
def String nom = issue.getCustomFieldValue(nomCF)
def String prenom = issue.getCustomFieldValue(prenomCF)
 
def String mail = prenom  + "." + nom + "@canaltp.fr"
      
return mail