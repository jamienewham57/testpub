// This script calculates the margin for a ticket

import com.atlassian.plugin.PluginAccessor
  
import java.util.HashMap
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.customfields.option.Option
import com.atlassian.jira.issue.customfields.view.CustomFieldParams
import com.atlassian.jira.issue.customfields.option.LazyLoadedOption
import com.atlassian.jira.issue.customfields.impl.CascadingSelectCFType
  
enableCache = {-> false}
  
def customFieldManager = ComponentAccessor.getCustomFieldManager();
  
def charged_cf = customFieldManager.getCustomFieldObject( "customfield_13532");
//"Supplier Invoice amount"
def invoiced_cf = customFieldManager.getCustomFieldObject( "customfield_13534");
//"Client Invoice amount \($\)"
def charged = issue.getCustomFieldValue(charged_cf);
def invoiced = issue.getCustomFieldValue(invoiced_cf);

Double margin = 0.0

//log.error(charged + " " + invoiced)

if(charged != null && invoiced != null) {
	margin = ((Double)invoiced - (Double)charged) / (Double)invoiced * 100;
    if((Double)invoiced < 0.0)
        margin = -margin 
}

//log.error(margin)
  
return margin?.round(2);