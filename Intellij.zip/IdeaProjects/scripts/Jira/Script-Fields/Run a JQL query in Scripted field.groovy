import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.jql.parser.JqlQueryParser
 
def componentManager = ComponentManager.getInstance()
def issueManager = componentManager.getIssueManager()
def searchService = componentManager.getSearchService()
def jqlQueryParser = ComponentManager.getComponentInstanceOfType(JqlQueryParser.class)
 
//get the issue
Issue issue  = issue
def id=issue.getId()
 
//define query
def query1 = "assignee in membersOf('jira-users')"
def query2 = "assignee in membersOf('jira-administrators')"
 
//parse the query
def query1parse = jqlQueryParser.parseQuery("issue = "+ id + " AND " + query1)
def query2parse = jqlQueryParser.parseQuery("issue = "+ id + " AND " + query2)
 
//get issues with query
def q1 = searchService.searchCount(ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser(), queryp1parse)
def q2 = searchService.searchCount(ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser(), query2parse)
 
if (q1)
{
    return "Users"
    }
else if (q2)
    {
    return "Admins"
     }