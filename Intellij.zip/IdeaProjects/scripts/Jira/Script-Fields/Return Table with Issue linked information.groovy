import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.link.IssueLinkImpl
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def version_number = customFieldManager.getCustomFieldObject('customfield_10011')
def issueLinkManager = ComponentAccessor.getIssueLinkManager()
def message = "<style> table, th, td {   border: 1px solid black;    border-collapse: collapse;}th, td {    padding: 5px;    text-align: left;}</style><table><tr><th>Issuekey</th><th>Summary </th><th>Version Number</th></tr>"
issueLinkManager.getOutwardLinks(issue.id).each {issueLink -> 
    def linkedissuetype = issueLink.getDestinationObject().getIssueType().getName()
    def linkedOriginalEstimate = issueLink.getDestinationObject().getOriginalEstimate()
    if (issueLink.issueLinkType.id == 10003){
            def version_number_value = issueLink.getDestinationObject().getCustomFieldValue(version_number)
            def issuekey = issueLink.getDestinationObject().getKey()
            def summary = issueLink.getDestinationObject().getSummary()
            message = message + "<tr><td>" + issuekey + "</td><td>" + summary + "</td><td>" + version_number_value + "</td></tr>"
        }
    }
          
return message + "</table>"