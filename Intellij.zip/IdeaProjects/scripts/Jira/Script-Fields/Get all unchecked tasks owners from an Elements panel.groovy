import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.plugin.PluginAccessor
import com.atlassian.jira.user.ApplicationUser
 
PluginAccessor pluginAccessor = ComponentAccessor.getPluginAccessor()
Class panelContentServiceClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.content.PanelContentService")
Class panelRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.PanelRef")
Class attributeRefClass = pluginAccessor.getClassLoader().findClass("com.valiantys.software.elements.api.model.AttributeRef")
def userManager = ComponentAccessor.getUserManager() 

def issueManager = ComponentAccessor.getIssueManager()
def panelContentService = ComponentAccessor.getOSGiComponentInstanceOfType(panelContentServiceClass)

// Define Elements panel
def tasksPanel = panelContentService.getPanel(issue, panelRefClass.byName("Tasks to do"))
def getBackPanel = panelContentService.getPanel(issue, panelRefClass.byName("Get back"))
def accessPanel = panelContentService.getPanel(issue, panelRefClass.byName("Access to remove"))

def panels = [tasksPanel, getBackPanel, accessPanel]

// Get Elements panel items
Set<ApplicationUser> usersSet = new HashSet<ApplicationUser>()
for(def panel : panels) {
    for (def panelItem : panel.getPanelItems()) {
        def taskDone = panelItem .getAttributeContent(attributeRefClass.byName(" "))?.getValue()
        if(!taskDone) {
            def owner = panelItem .getAttributeContent(attributeRefClass.byName("Owner"))?.getValue()
            if(owner != null) {
                usersSet.add(userManager.getUserByName(owner))
            }
        }

    }
}

return usersSet