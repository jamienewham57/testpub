import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
  
  
def changeHolder = new DefaultIssueChangeHolder()
   
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def text_field_f = customFieldManager.getCustomFieldObject('customfield_16200')
def issueproject = issue.getProjectId()
if (issueproject == 10204 ){
     
    def issueLinkManager = ComponentAccessor.getIssueLinkManager()
    def parent_value
    issueLinkManager.getOutwardLinks(issue.id).each {issueLink -> 
         
        //def linkedissuetype = issueLink.getDestinationObject().getIssueType().getName()
        if (issueLink.issueLinkType.id == 10400 and !parent_value){
            parent_value = issueLink.getDestinationObject().getKey()
        }
     
     
        }
   if (parent_value){
    text_field_f.updateValue(null,issue, new ModifiedValue(issue.getCustomFieldValue(text_field_f),parent_value.toString()),changeHolder)
    issue.store()
    }
     
}