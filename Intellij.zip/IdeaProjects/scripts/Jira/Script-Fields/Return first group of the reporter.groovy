import com.atlassian.jira.ComponentManager
import com.atlassian.jira.security.groups.GroupManager
GroupManager groupManager = ComponentManager.getComponentInstanceOfType(GroupManager.class)
GroupList = groupManager.getGroupsForUser(issue.getReporterId()).name;
return GroupList[0];