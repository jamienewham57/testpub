import com.atlassian.jira.component.ComponentAccessor
import groovy.sql.Sql
import org.ofbiz.core.entity.ConnectionFactory
import org.ofbiz.core.entity.DelegatorInterface
import com.atlassian.jira.issue.Issue
import java.sql.Connection
  
def delegator = (DelegatorInterface) ComponentAccessor.getComponent(DelegatorInterface)
String helperName = delegator.getGroupHelperName("default")
Issue issue = issue
Connection conn = ConnectionFactory.getConnection(helperName)
Sql sql = new Sql(conn)
  
//SQL Query - differs for each database
def sqlStmt = """
select * from project
"""
def row = sql.rows(sqlStmt)
String value = ""
sql.rows(sqlStmt).findAll {row}.each{
    comments += "${it.pname}"
}
return value