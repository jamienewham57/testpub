// version JIRA 7.2.2
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.jql.parser.JqlQueryParser
    
 
def changeHolder = new DefaultIssueChangeHolder()
final id=issue.getId()
def componentManager = ComponentManager.getInstance()
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
 
//def searchService = componentManager.getSearchService()
//final SearchService searchService = componentManager.getSearchService();
final searchService = ComponentAccessor.getComponentOfType(SearchService.class)
def jqlQueryParser = ComponentManager.getComponentInstanceOfType(JqlQueryParser.class)
    
def non_html_valueF = customFieldManager.getCustomFieldObjectByName("RAG")
 
 
def ufsredquery = "project = 'PJAB' AND duedate < now()"
def ufsgreenquery = "project = 'PJAB' AND duedate > 14d"
def ufsamberquery = "project = 'PJAB' AND duedate > now() AND duedate < 14d"
    
def ufsredslaquery = jqlQueryParser.parseQuery("issue = "+ id + " AND " + ufsredquery)
def ufsgreenslaquery = jqlQueryParser.parseQuery("issue = "+ id + " AND " + ufsgreenquery)
def ufsamberslaquery = jqlQueryParser.parseQuery("issue = "+ id + " AND " + ufsamberquery)
    
def ufsred   = searchService.searchCount(ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser(), ufsredslaquery)
def ufsgreen = searchService.searchCount(ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser(), ufsgreenslaquery)
def ufsamber = searchService.searchCount(ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser(), ufsamberslaquery)
    
 
def html_value
def non_html_value
if (ufsred)
{
html_value="<span class=\"aui-lozenge aui-lozenge-error\">R</span>"
non_html_value = "Red"
}
else if (ufsgreen)
{
html_value="<span class=\"aui-lozenge aui-lozenge-success\">G</span>"
non_html_value = "Green"
}
else if (ufsamber)
{
html_value="<span class=\"aui-lozenge aui-lozenge-current\">A</span>"
non_html_value = "Amber"
} else {
    html_value=null
    non_html_value = ""
}
    
non_html_valueF.updateValue(null,issue, new ModifiedValue(issue.getCustomFieldValue(non_html_valueF),non_html_value.toString()),changeHolder)
log.error(html_value)
log.error(non_html_value)
return html_value