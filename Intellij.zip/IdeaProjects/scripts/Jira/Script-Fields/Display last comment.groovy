import com.atlassian.jira.component.ComponentAccessor

def commentManager = ComponentAccessor.getCommentManager()

def comments = commentManager.getComments(issue)

if(comments != null) {
    if(comments.size() > 0) {
 	return comments.last()?.body
    }
}