import com.atlassian.jira.component.ComponentAccessor

def customFieldManager = ComponentAccessor.getCustomFieldManager()

def businessUnitCf = customFieldManager.getCustomFieldObject("customfield_13332")
def sygesCustomerCf = customFieldManager.getCustomFieldObject("customfield_14630")

if(!issue.getCustomFieldValue(businessUnitCf)?.getValue().equals("UK")) {
    if(issue.getCustomFieldValue(sygesCustomerCf) == null) {
        return "<div class=\"aui-message aui-message-error\">Syges customer is mandatory!</div>"
    }
}