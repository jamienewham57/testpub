import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.customfields.option.Option;
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def Impactf = customFieldManager.getCustomFieldObject('customfield_10802')
def Urgencyf = customFieldManager.getCustomFieldObject('customfield_10803')
//def Impact = issue.getCustomFieldValue(Impactf)
def Urgency = ((Option)issue.getCustomFieldValue(Urgencyf)).getValue();
def Impact = ((Option)issue.getCustomFieldValue(Impactf)).getValue();
def RES=""
if ("Bloquant>10".equals(Impact) && "Critique".equals(Urgency)) {RES="S1"} else if ("Bloquant>10".equals(Impact) && ("Forte".equals(Urgency) || "Faible".equals(Urgency) )) {RES="S2"} else if ("Bloquant 1".equals(Impact) && ("Critique".equals(Urgency) || "Forte".equals(Urgency) )) {RES="S2"} else if ("Non Bloquant".equals(Impact) && "Critique".equals(Urgency)) {RES="S2"} else {RES="S3"}
return RES