import groovyx.net.http.RESTClient
 
def issuekey = issue.getKey()
def RESTClient http
def hostname = "http://localhost"
def auth = 'admin:admin'.bytes.encodeBase64().toString()
http = new RESTClient(hostname)
http.setHeaders([Authorization: "Basic {$auth}"])
 
http.get(path: "/jira/rest/servicedeskapi/request/${issuekey}/sla/2").data.ongoingCycle.goalDuration.friendly