public class Functions {
    public Integer function1() {
        Integer result = 1;
		
		return result;
    }
	
	public String function2() {
        String result = "coucou cyrille";
		
		return result;
    }
	
}