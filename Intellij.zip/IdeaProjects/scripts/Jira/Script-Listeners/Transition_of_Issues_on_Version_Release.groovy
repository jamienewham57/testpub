import com.atlassian.jira.bc.issue.IssueService
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.project.VersionReleaseEvent
import com.atlassian.jira.event.issue.IssueEventBundle
import com.atlassian.jira.event.issue.IssueEventBundleFactory
import com.atlassian.jira.event.issue.IssueEventManager
import com.atlassian.jira.issue.IssueInputParameters
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.project.version.Version
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.web.bean.PagerFilter
 
import org.apache.log4j.Category
  
//Log type configuration
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG)
  
//Initialization of Managers
IssueEventBundleFactory issueEventFactory = (IssueEventBundleFactory) ComponentAccessor.getComponent(IssueEventBundleFactory.class)
IssueManager issueManager = ComponentAccessor.getIssueManager()
IssueEventManager issueEventM = ComponentAccessor.getIssueEventManager()
  
//Initialization of Variables
SearchService searchService = ComponentAccessor.getComponent(SearchService.class)
ApplicationUser userLogged = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
List<MutableIssue> list_Issue = new ArrayList<MutableIssue>();
IssueEventBundle eventBundle
Map param = null;
VersionReleaseEvent event = event as VersionReleaseEvent
Version version = event.version
String JQLsearch = 'project = TST AND status = \"To Be Delivered\" AND fixVersion = ' + version
String deliveryStatus = "10923" //ID status 'To Be Delivered'
int deliveryId = 11 //ID Transition 'Deliver'
  
//Launch JQL search + fetch the impacted Issues
log.debug(JQLsearch)
SearchService.ParseResult parseResult =  searchService.parseQuery(userLogged, JQLsearch)
if (parseResult.isValid()) {
    def searchResult = searchService.search(userLogged, parseResult.getQuery(), PagerFilter.getUnlimitedFilter())
    def JQLissues = searchResult.issues.collect {issueManager.getIssueObject(it.id)}
    for(MutableIssue issueSearch:JQLissues){
        log.debug("issue: " + issueSearch.getKey())
        list_Issue.add(issueSearch)
    }
}
else {
    log.error("Invalid JQL: " + JQLsearch)
}
 
 
//Fire the transition for each Issue
for(MutableIssue issue_version : list_Issue){
    log.debug("Clé: "+ issue_version.getKey())
    log.debug("Version: "+ issue_version.getFixVersions())
 
 
    try{
        IssueService issueService = ComponentAccessor.getIssueService()
        IssueInputParameters issueInputParameters = issueService.newIssueInputParameters();
        issueInputParameters.setStatusId(deliveryStatus); //Status 'To Be Delivered'
        IssueService.TransitionValidationResult transitionValidationResult = issueService.validateTransition(userLogged, issue_version.id, deliveryId, issueInputParameters);
 
        if (transitionValidationResult.isValid()){
            IssueService.IssueResult transitionResult = issueService.transition(currentUser, transitionValidationResult);
            if (!transitionResult.isValid()) {
                transitionResult.errorCollection.errorMessages.each {log.error "Error Message: $it"}
                transitionResult.errorCollection.errors.each {log.error "Error: $it"}
                transitionResult.errorCollection.reasons.each {log.error "Reason: $it"}
            } else {
                log.debug("Issue: " + issue_version.getKey() + "delivered !")
            }
        } else {
            transitionValidationResult.errorCollection.errorMessages.each {log.error "Error Message: $it"}
            transitionValidationResult.errorCollection.errors.each {log.error "Error: $it"}
            transitionValidationResult.errorCollection.reasons.each {log.error "Reason: $it"}
        }
    } catch (Exception e){
        log.error(e.getMessage());
    }
}
return