//this is where the file will be save, in my case it is ../scripts/com/icg/
package com.icg
  
import com.atlassian.jira.event.issue.AbstractIssueEventListener
import com.atlassian.jira.event.issue.IssueEvent
import org.apache.log4j.Category
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.security.JiraAuthenticationContext
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.customfields.manager.OptionsManager
import com.atlassian.jira.user.util.UserManager
import com.atlassian.crowd.embedded.api.User
   
ComponentManager componentManager = ComponentManager.getInstance()
def issueManager = ComponentAccessor.getIssueManager()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def optionsManager = componentManager.getComponentInstanceOfType(OptionsManager.class)
   
MutableIssue issue  = event.issue as MutableIssue
  
UserManager userManager = ComponentAccessor.getUserManager()
def admin_user = userManager.getUserByName('admin')
  
def impact = ComponentAccessor.customFieldManager.getCustomFieldObjects(issue).find{it.id =='customfield_10101'}
def urgency = ComponentAccessor.customFieldManager.getCustomFieldObjects(issue).find{it.id =='customfield_10102'}
  
def impactval = issue.getCustomFieldValue(impact)
log.debug("VAL "+ impactval)
def urgencytval = issue.getCustomFieldValue(urgency)
log.debug("VAL "+ urgencytval)
  
def impactfieldConfig = impact.getRelevantConfig(issue)
def urgencyfieldConfig = urgency.getRelevantConfig(issue)
   
def impacthigh = optionsManager.getOptions(impactfieldConfig).find {it.value == "1"}
def impactmedium = optionsManager.getOptions(impactfieldConfig).find {it.value == "2"}
def impactlow = optionsManager.getOptions(impactfieldConfig).find {it.value == "3"}
  
def urgencyhigh = optionsManager.getOptions(urgencyfieldConfig).find {it.value == "1"}
def urgencymedium = optionsManager.getOptions(urgencyfieldConfig).find {it.value == "2"}
def urgencylow = optionsManager.getOptions(urgencyfieldConfig).find {it.value == "3"}
   
if(impactval == impacthigh && urgencytval == urgencyhigh)
    {
issue.setPriorityId("1")
issueManager.updateIssue(admin_user, issue, EventDispatchOption.DO_NOT_DISPATCH, false)
    }
else if(impactval == impactmedium && urgencytval == urgencymedium )
    {
issue.setPriorityId("2")
issueManager.updateIssue(admin_user, issue, EventDispatchOption.DO_NOT_DISPATCH, false)
    }
