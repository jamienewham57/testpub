import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.user.ApplicationUsers
import com.atlassian.jira.bc.issue.IssueService.TransitionValidationResult
import com.atlassian.jira.bc.issue.IssueService
import com.atlassian.jira.issue.IssueInputParameters
import javax.servlet.http.HttpServletRequest
import com.atlassian.jira.web.ExecutingHttpRequest
import org.apache.log4j.Category
 
// Debug
//Category log = log;
//log.setLevel(org.apache.log4j.Level.DEBUG)
 
// Managers
def issueManager = ComponentAccessor.getIssueManager()
def issueLinkManager = ComponentAccessor.getIssueLinkManager()
def eventManager = ComponentAccessor.getIssueEventManager()
def userManager = ComponentAccessor.getUserManager()
def issueService = ComponentAccessor.getComponent(com.atlassian.jira.bc.issue.IssueService)
 
// Constantes et variables
def issue = event.getIssue()
def myLink = 10003
def user = event.getUser()
def Issue linkedIssue = null
def transitionId = null
// Recherche d'une demande liée à synchroniser
def inwardLinks = issueLinkManager.getInwardLinks(issue.getId()) // Dans un sens
for (IssueLink oneLink : inwardLinks) {
    if (oneLink.getLinkTypeId() == myLink){
        linkedIssue = oneLink.getSourceObject()
    }
}
if (linkedIssue == null){
    def outwardLinks = issueLinkManager.getOutwardLinks(issue.getId()) // Puis dans l'autre
    for (IssueLink oneLink : outwardLinks) {
        if (oneLink.getLinkTypeId() == myLink){
            linkedIssue = oneLink.getDestinationObject()
        }
    }
}
// Le check des deux sens ne sera pas forcément utilse si les demandes sont liées avec Exocet: le sens sera connu
 
// Identification de la transition passée
HttpServletRequest request = ExecutingHttpRequest.get()
if (request != null){
    transitionId = request.getParameter("action")   
    // Exécution de la transition sur la demande liée
    if (transitionId != null && user.getName() != "robot" && linkedIssue != null){
        // On éxécute avec le robot pour éviter les boucles
        def userRobot = userManager.getUserByName("robot")
        def transitionResult = issueService.validateTransition(userRobot, linkedIssue.getId(), Integer.parseInt(transitionId), issueService.newIssueInputParameters())
        if (transitionResult.isValid()){
            issueService.transition(userRobot, transitionResult)
        }
    }
}
// Si la requête est nulle, cela signifie que la transition est passée par programmation
// On gère ce cas avec deux autres listeners (les deux cas sont: réponse du client par commentaire / réouverture par commentaire du client)