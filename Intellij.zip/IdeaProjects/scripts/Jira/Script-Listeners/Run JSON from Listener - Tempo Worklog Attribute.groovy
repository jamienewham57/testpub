import com.atlassian.jira.issue.worklog.WorklogImpl
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.worklog.WorklogManager
import com.atlassian.jira.component.ComponentAccessor
 
//Get the latest worklog
 
ComponentManager componentManager = ComponentManager.getInstance()
WorklogManager worklogManager = ComponentAccessor.getWorklogManager()
MutableIssue issue  = event.issue as MutableIssue
 
String worklogsid = ""
    worklogManager.getByIssue(issue).findAll{
    worklogsid += it.id + ","
}
 
String lodID = worklogsid.tokenize(',').last()
 
// Get the Issue Key
def issuekey = issue.getKey()
 
//Get the Project ID
def projectid = issue.getProjectId()
 
// JSON to Update tempo worklog attribute "_Test_"
 
//Get CF Value Team
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def cfteam = customFieldManager.getCustomFieldObject("customfield_10104")
def cfteamvalue = issue.getCustomFieldValue(cfteam)
 
def testatt = """{
  "issue": {
    "projectId": "${projectid}",
    "key": "${issuekey}"
  },
  "worklogAttributes": [
    {
      "key": "_Test_",
      "value": "${cfteamvalue}"
    }
  ]
}"""
 
//correct for Tempo to PUT
def temporest = ["curl", "-H", "Content-Type: application/json", "-X", "PUT", "-d", "${testatt}", "http://admin:admin@localhost:8080/rest/tempo-timesheets/3/worklogs/${lodID}"].execute().text