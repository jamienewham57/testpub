 /** Depending on the value stored in :
customfield_10402 (text custom field)
we shall decide which delay we should set in the current
issue duedate (now + delay).
**/

/*
Full context :
Issue is created via Exocet Operation to be created on a post-function, with some field mapping to specify which delay is to be added to the current date.
Issue creation fires custom event, "Issue Created Date", to which is hooked this listener.

Notes :
didn't managed to set this in Exocet mapping directly (velocity context doesn't provide "now" info.)
didn't managed to set this as a postfunction on the "create" transition (the custom field value wasn't initialized yet).
tested on JIRA 7.2.2

*/
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.Issue;
 
import java.sql.Timestamp
import com.atlassian.jira.issue.MutableIssue
 
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.user.util.UserManager
import com.atlassian.crowd.embedded.api.User
 
// ---------- DATA
/** https://axa-banque-test.valiantyscloud.net/secure/admin/ConfigureCustomField!default.jspa?customFieldId=10402
    PJAB-penal-forclos
    PJAB-penal-appel
    PJAB-penal-cassation
    PJAB-civil-appel
    PJAB-civil-cassation
*/
def CFautomaticDelay="customfield_10402";
 
// Decide which delay to add depending on CF value :
def PJABpenalforclos    =  6*30
def PJABpenalappel      = 10
def PJABpenalcassation  =  5
def PJABcivilappel      = 30
def PJABcivilcassation  =  2*30
def addedDelay  = 0;
 
// ---------- PROCESS
log.debug("event.issue.id:"+event.issue.id)
def issueManager = ComponentAccessor.getIssueManager()
def MutableIssue issue = issueManager.getIssueObject(event.issue.id)
 
// Get the value from customfield_10401
def customFieldManager = ComponentAccessor.getComponent(CustomFieldManager);
//def cField = customFieldManager.getCustomFieldObjectByName("Automatic Delay");
def cField = customFieldManager.getCustomFieldObject(CFautomaticDelay);
 
def String cFieldValue = issue.getCustomFieldValue(cField)
 
log.debug("cField: " + cField)
log.debug("cFieldValue: "+ cFieldValue)
 
// Define the delay depending on the CF value
switch (cFieldValue) {
    case ~/PJAB-penal-forclos/   : addedDelay += PJABpenalforclos; log.debug("case:"+"PJAB-penal-forclos") ; break;
    case ~/PJAB-penal-appel/     : addedDelay += PJABpenalappel;  log.debug("case:"+"PJAB-penal-appel") ; break;
    case ~/PJAB-penal-cassation/ : addedDelay += PJABpenalcassation;  log.debug("case:"+"PJAB-penal-cassation") ; break;
    case ~/PJAB-civil-appel/     : addedDelay += PJABcivilappel;  log.debug("case:"+"PJAB-civil-appel") ; break;
    case ~/PJAB-civil-cassation/ : addedDelay += PJABcivilcassation;  log.debug("case:"+"PJAB-civil-cassation") ; break;
    default :  log.debug("case:"+"default") ; return null; // this case means we created it by hand, we do not want to change the manually entered value.
}
 
 
// ---------- WRITE OUTPUT
// Get the "now" time
// Set value in "duedate"
log.debug (""+new Timestamp((new Date() + addedDelay).time))
issue.setDueDate(new Timestamp((new Date() + addedDelay).time))
 
issueManager.updateIssue(event.user, issue, EventDispatchOption.DO_NOT_DISPATCH, false)