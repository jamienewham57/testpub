//this is where the file will be save, in my case it is ../scripts/com/icg/
package com.icg
 
import com.atlassian.jira.event.issue.AbstractIssueEventListener
import com.atlassian.jira.event.issue.IssueEvent
import org.apache.log4j.Category
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.security.JiraAuthenticationContext
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.user.util.UserManager
import com.atlassian.crowd.embedded.api.User
 
//this is my class name and file name
class ClassName extends AbstractIssueEventListener {
Category log = Category.getInstance(ClassName.class)
  
    ClassName () {
        log.setLevel(org.apache.log4j.Level.DEBUG)
    }
  
    @Override
//I will be looking for issue assigned event
    void issueAssigned(IssueEvent event) {
log.debug "Event: ${event.getEventTypeId()} fired for ${event.issue} and caught by Assigned"
 
ComponentManager componentManager = ComponentManager.getInstance()
def issueManager = componentManager.getIssueManager()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
 
MutableIssue issue  = event.issue
def id=issue.getId()
 
UserManager userManager = ComponentAccessor.getUserManager()
User usera = userManager.getUser('username')
 
def field = customFieldManager.getCustomFieldObject('customfield_XXXXX')
def groupManager = ComponentAccessor.getGroupManager()
 
if(groupManager.getGroupNamesForUser(issue.assignee).contains("group-name"))
{
issue.setCustomFieldValue(field, "the string")
issueManager.updateIssue(usera, issue, EventDispatchOption.ISSUE_ASSIGNED, false)
    }
else if(groupManager.getGroupNamesForUser(issue.assignee).contains("group-name"))
    {
issue.setCustomFieldValue(field, "the string")       
issueManager.updateIssue(usera, issue, EventDispatchOption.ISSUE_ASSIGNED, false)
     }
}
}