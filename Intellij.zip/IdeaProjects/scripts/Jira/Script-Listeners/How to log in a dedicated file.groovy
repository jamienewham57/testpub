/*

Use Case : Groovy scripts shall be log in a dedicated file in %JIRA_HOME%/log
This function can be used on each type of script
Tested on JIRA 7.3.x and Script runner > 5
*/

import com.atlassian.jira.logging.JiraHomeAppender
import com.atlassian.jira.startup.JiraHomeStartupCheck
import org.apache.log4j.PatternLayout
import org.apache.log4j.Logger
 
def setScriptRunnerLogger(){
Logger logger;
String LOG4J_PATTERN_LAYOUT = "%d{yyyy-MM-dd}-%t-%x-%-5p-%-10c:%m%n";
String aLogFilePath = "script-runner.log";
JiraHomeAppender fileAppender = new JiraHomeAppender(JiraHomeStartupCheck.getInstance());
fileAppender.setLayout(new PatternLayout(LOG4J_PATTERN_LAYOUT));
fileAppender.setFile(aLogFilePath);
fileAppender.setMaxFileSize("20480KB");
fileAppender.setThreshold(org.apache.log4j.Level.DEBUG);
fileAppender.setMaxBackupIndex(5);
  
logger = Logger.getLogger(String.valueOf(new Date().getTime()));
logger.setLevel(org.apache.log4j.Level.DEBUG);
logger.addAppender(fileAppender);
 
return logger;
}
 
Logger log = (Logger)setScriptRunnerLogger();
 
log.debug "Start Script";
 
//Constants
String YES = "<font color=\"green\">Yes</font>";
 
log.debug "End Script";
return YES;