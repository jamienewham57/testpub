package com.onresolve.jira.groovy.canned.workflow.listeners
import com.onresolve.jira.groovy.canned.CannedScript
import com.atlassian.jira.util.ErrorCollection
import org.apache.log4j.Category
import com.atlassian.jira.util.SimpleErrorCollection
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.changehistory.ChangeHistory
import com.atlassian.jira.issue.history.ChangeItemBean
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.event.issue.IssueEventManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.ApplicationUser
 
class FireAttachmentEvent implements CannedScript {
    Category log = Category.getInstance(FireAttachmentEvent.class)
    String getName() {
        return "Fire attachment event"
    }
    String getDescription() {
        return "Fire attachment event description"
    }
    List getCategories() {
        ["Listener"]
    }
    List getParameters(Map params) {
        [
                [
                        Name:"FireAttachmentEvent",
                        Label:"FireAttachmentEvent",
                        Description:"""Fully-qualified class name class in the form com.acme.MyListener""",
                ]
        ]
    }
    ErrorCollection doValidate(Map params, boolean forPreview) {
        def errorCollection = new SimpleErrorCollection()
        def gcl = this.class.getClassLoader()
        if (! params["clazz"]) {
            errorCollection.addError("clazz", "You must provide a class name.")
        }
        else {
            try {
                gcl.loadClass(params["clazz"] as String, true, false).newInstance()
            }
            catch (Exception e) {
                errorCollection.addError("clazz", "Problem loading class: " + e.message)
            }
        }
        errorCollection
    }
    Map doScript(Map params) {
        log.debug(params)
        // this is the old custom listener... run it
        def gcl = this.class.getClassLoader()
        assert params["clazz"] as String
        Object delegate = gcl.loadClass(params["clazz"] as String, true, false).newInstance();
        if (! (delegate.respondsTo("workflowEvent"))) {
            log.warn("Listener class must implement workflowEvent(IssueEvent event).")
        }
        delegate.workflowEvent(params["event"])
        return params
    }
    String getDescription(Map params, boolean forPreview) {
        return "Custom listener: ${params['clazz']}"
    }
    Boolean isFinalParamsPage(Map params) {
        true
    }
    @Override
    void workflowEvent(IssueEvent event) {
        log.debug "Event: ${event.getEventTypeId()} fired for ${event.issue} and caught by FireAttachmentEvent"
        ComponentManager componentManager = ComponentManager.getInstance()
        IssueEventManager issueEventManager = ComponentAccessor.getIssueEventManager()
        IssueManager issueManager = componentManager.getIssueManager()
        ApplicationUser loggedInUser = ComponentAccessor.getJiraAuthenticationContext().getUser()
        ChangeHistory changeHistory = new ChangeHistory(event.getChangeLog(), issueManager)
        if(changeHistory == null) {
            log.debug "changeHistory is null"
            return
        }
         
        def boolean fire = false
         
        for(ChangeItemBean changeItemBean : changeHistory.getChangeItemBeans()) {
            if(changeItemBean.getFieldType() == "jira" && changeItemBean.getField() == "Attachment" && changeItemBean.getFromString() == null && (changeItemBean.getToString() != null || changeItemBean.getToString() != "")){
                fire = true
            }
        }
        if(fire){
            log.debug "Fire event!"
            issueEventManager.dispatchEvent(10001, event.getIssue(), loggedInUser.getDirectoryUser(), event.getChangeLog(), true, false)
            // 10001 = Attachment added event => you need to change it
        }      
    }
}