package boulanger

import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.link.IssueLinkManager
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.user.util.UserManager
import com.atlassian.jira.web.bean.PagerFilter
import org.apache.log4j.Category
import org.apache.log4j.Level
import org.apache.log4j.Logger

Category log = Logger.getLogger("com.boulanger.LinkIssuesFromVersion")
log.setLevel(Level.DEBUG)

// IssueEvent event
log.debug("Starting...")
MutableIssue currentIssue = (MutableIssue) event.issue

//Manager
IssueLinkManager issueLinkManager = ComponentAccessor.issueLinkManager
IssueManager issueManager = ComponentAccessor.issueManager
UserManager userManager = ComponentAccessor.getUserManager()
SearchService searchService = ComponentAccessor.getComponent(SearchService.class)

long RELATES_TO_LINK_TYPE_ID = 10003l

String listVersion = currentIssue.fixVersions.collect { version -> "\"" + version.name + "\"" }.join(",")
String jqlSearch = "fixVersion in (" + listVersion + ")"

ApplicationUser admin = userManager.getUserByName("jira_admin")

SearchService.ParseResult parseResult = searchService.parseQuery(admin, jqlSearch)
if (parseResult.isValid()) {
    def searchResult = searchService.search(admin, parseResult.getQuery(), PagerFilter.getUnlimitedFilter())
    List<MutableIssue> issues = searchResult.issues.collect { issueManager.getIssueObject(it.id) }

    log.debug "Found ${issues.size()} issues to link"

    issues.each { linkedIssue ->
        issueLinkManager.createIssueLink(linkedIssue.getId(), currentIssue.getId(), RELATES_TO_LINK_TYPE_ID, 0l, admin)
    }
} else {
    log.error("Invalid JQL: " + jqlSearch)
}

log.debug "Ending..."