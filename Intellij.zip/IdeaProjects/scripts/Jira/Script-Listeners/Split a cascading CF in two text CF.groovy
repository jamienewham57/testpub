import com.atlassian.event.api.EventListener
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.issue.AbstractIssueEventListener
import com.atlassian.jira.event.issue.IssueEvent
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.fields.CustomField
import org.apache.log4j.Logger
 
def cfNameCascading = "Projets et domaines";
def cfNameFirst     = "Projets et domaines : Projets";
def cfNameSecond    = "Projets et domaines : Domaines";
 
IssueManager issueManager = ComponentAccessor.getIssueManager()
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
 
/** Get the different CF objects**/
CustomField cfCascading = customFieldManager.getCustomFieldObjectByName(cfNameCascading)
CustomField cfFirst = customFieldManager.getCustomFieldObjectByName(cfNameFirst)
CustomField cfSecond = customFieldManager.getCustomFieldObjectByName(cfNameSecond)
 
/** Get Cascading Field values (map) **/
Map cfVal = issue.getCustomFieldValue(cfCascading) as Map
if (cfVal) {
    String valFirst = cfVal.get(null);
    String valSecond = cfVal.get("1");
    List allValues = cfVal.values() as List;
 
    log.info("First - second: $valFirst - $valSecond");
    log.info("All: $allValues");
 
    /** Set each separate CF **/
    issue.setCustomFieldValue(cfFirst,  valFirst);
    issue.setCustomFieldValue(cfSecond, valSecond);
 
    /** update the issue **/
    issueManager.updateIssue(event.getUser(), issue, EventDispatchOption.DO_NOT_DISPATCH, false);
} else {
    log.info("Custom field not present on this issue")
}