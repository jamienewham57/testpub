import com.atlassian.jira.component.ComponentAccessor
def commentManager = ComponentAccessor.getCommentManager()
def comments = commentManager.getComments(issue)
comments.last().body.contains("Text")