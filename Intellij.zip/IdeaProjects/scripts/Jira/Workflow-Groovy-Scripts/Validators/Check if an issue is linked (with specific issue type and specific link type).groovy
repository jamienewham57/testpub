import org.apache.log4j.Categoryimport webwork.action.ActionContext
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
  
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG);
  
def linkType = 'Relates'
def IssueType = 'New Requirement'
def isReqLinked = false
  
log.debug "****** Validator : Is there a link to a " + IssueType + "?"
  
issueLinkManager.getOutwardLinks(issue.id).each{ issueLink ->
    //only check reqIssueType Links with linkType
    if(issueLink.issueLinkType.name.contains(linkType)) { // if link is ...
        def thislink = issueLink.getDestinationObject().getIssueType()*.name.contains(IssueType) // is linked issue type ... ?
        log.debug "Is this a linked " + IssueType + "? " + thislink + " (" + issueLink.getDestinationObject().key + ") "
        isReqLinked = isReqLinked || thislink
    }
}
log.debug "Is there a " + IssueType + " already linked? " + isReqLinked
  
if (isReqLinked == false){
    def request = ActionContext.getRequest()
    if (! request) {
        return true // submitted through REST API - we can't do anything about this
    }
      
    def linkedIssueKeys = request.getParameterValues("issuelinks-issues")
    def linkedIssueType = request.getParameter("issuelinks-linktype")
      
    log.debug("linked issues: " + linkedIssueType) //
    log.debug("linked issues: " + linkedIssueKeys) //
      
    if (!linkedIssueType || !linkedIssueKeys){
        log.debug "No issue linked ! Validation KO !"
        return false
    }
    else{
        log.debug "issue linked ! : " + linkedIssueKeys
        return true
    }
}
else{
    log.debug "A " + IssueType + " is already linked !"
}
  
return isReqLinked