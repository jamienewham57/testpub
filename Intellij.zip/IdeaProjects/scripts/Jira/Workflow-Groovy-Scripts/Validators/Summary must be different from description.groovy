issue.summary != issue.description
