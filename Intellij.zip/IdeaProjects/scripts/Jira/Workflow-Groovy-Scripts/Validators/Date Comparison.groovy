Date now = new Date()
Date cfDate = new Date(cfValues['Date and Time of the incident'].getTime())
long elapsedTime= (now.getTime() - cfDate.getTime())
boolean res = (elapsedTime>= 0)
return res
//new Date(now.getYear(), now.getMonth(), now.getDate()).compareTo(cfDate) > 0