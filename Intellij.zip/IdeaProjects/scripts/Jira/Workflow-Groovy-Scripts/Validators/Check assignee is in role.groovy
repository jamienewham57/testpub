import org.apache.log4j.Categoryimport com.atlassian.jira.ComponentManager
import com.atlassian.jira.security.roles.ProjectRoleActors
import com.atlassian.jira.security.roles.ProjectRoleManager
  
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG);
  
String role = 'Developer'
  
log.debug "****** Validator : Is Assignee in " + role + " Role?"
log.debug "issue.assignee :" + issue.assignee
  
ProjectRoleManager projectRoleManager = ComponentManager.getComponentInstanceOfType(ProjectRoleManager.class)
ProjectRoleActors projectRoleActors = projectRoleManager.getProjectRoleActors(projectRoleManager.getProjectRole(role), issue.getProjectObject())
log.debug "Is Assignee in Developer Role? " + projectRoleActors.getUsers().contains(issue.assignee)
projectRoleActors.getUsers().contains(issue.assignee)