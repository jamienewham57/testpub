import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.event.type.EventDispatchOption
import org.apache.log4j.Category
import com.atlassian.jira.util.ImportUtils
import com.atlassian.jira.issue.index.IssueIndexManager
Category log = log
log.setLevel(org.apache.log4j.Level.DEBUG);
log.debug "Start PostFunction =====> deleteAllSubtask.groovy";
def issueManager = ComponentAccessor.getIssueManager();
def indexManager = ComponentAccessor.getComponent(IssueIndexManager.class);
def userManager = ComponentAccessor.getUserManager();
def isIndexIssues = ImportUtils.isIndexIssues();
def isHeld = indexManager.isHeld();
//Users
def user_for_treatment = userManager.getUserObject("admin");
//Unlock issue index
if (!isIndexIssues) {
    ImportUtils.setIndexIssues(true);
}
if (isHeld) {
    try {
        indexManager.release();
    } catch (Throwable e) {
        log.error(e);
    }
}
Collection subTasksIssues = issue.getSubTaskObjects();
Issue subtaskToDelete;
for (int i = 0; i < subTasksIssues.size(); i++) {
    subtaskToDelete = subTasksIssues.get(i);
    log.debug "Issue to delete" + subTasksIssues.get(i);
    issueManager.deleteIssue(user_for_treatment, subtaskToDelete , EventDispatchOption.ISSUE_DELETED, false)
}
//Lock issue index
if (isHeld) {
    indexManager.hold();
}
ImportUtils.setIndexIssues(isIndexIssues);
log.debug "Stop PostFunction =====> deleteAllSubtask.groovy";