import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.jql.parser.JqlQueryParser
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
 
 
def changeHolder = new DefaultIssueChangeHolder()
  
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
 
def jqlQueryParser = ComponentAccessor.getComponent(JqlQueryParser)
def searchProvider = ComponentAccessor.getComponent(SearchProvider)
def issueManager = ComponentAccessor.getIssueManager()
def user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
  
//get the custom field I will look for in my JQL and format the value as expected
def request_type = customFieldManager.getCustomFieldObject('customfield_18411')
def request_type_value = issue.getCustomFieldValue(request_type)
def suppliers = request_type_value.toString().replace(";",",")
  
//get the custom field I want to set in the current issue
def email = customFieldManager.getCustomFieldObject('customfield_17418')
def email_value = ""
 
// edit this query to suit
def query = jqlQueryParser.parseQuery("project = SD and issuekey in ("+ suppliers +")")
def results = searchProvider.search(query, user, PagerFilter.getUnlimitedFilter())
results.getIssues().each {documentIssue ->
    log.debug(documentIssue.key)
    // if you need a mutable issue you can do:
    def issue = issueManager.getIssueObject(documentIssue.id)
    //set the value with all values from all issues returned by JQL comma separated
    email_value += issue.getCustomFieldValue(email) + ", "
}
  
email.updateValue(null,issue, new ModifiedValue(issue.getCustomFieldValue(email),email_value),changeHolder)