import com.atlassian.jira.bc.projectroles.ProjectRoleService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.security.roles.ProjectRoleActor
import com.atlassian.jira.security.roles.ProjectRoleManager
import com.atlassian.jira.util.SimpleErrorCollection
 
def projectManager = ComponentAccessor.getProjectManager()
def projectRoleService = ComponentAccessor.getComponent(ProjectRoleService)
def projectRoleManager = ComponentAccessor.getComponent(ProjectRoleManager)
def errorCollection = new SimpleErrorCollection()
def commentManager = ComponentAccessor.getCommentManager()
def currentUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
 
def projectCf = customFieldManager.getCustomFieldObject("customfield_XXXXX")
def Project project = issue.getCustomFieldValue(projectCf) as Project
def rolesCf = customFieldManager.getCustomFieldObject("customfield_XXXXY")
def List<String> projectRoles = (List<String>) issue.getCustomFieldValue(rolesCf);
def userCf = customFieldManager.getCustomFieldObject("customfield_XXXXZ")
def ApplicationUser user = issue.getCustomFieldValue(userCf) as ApplicationUser
 
def actors = [user.getUsername()]
 
projectRoles.each { projectRole ->
    projectRoleService.addActorsToProjectRole(actors,
        projectRole,
        project,
        ProjectRoleActor.USER_ROLE_ACTOR_TYPE,
        errorCollection)
};
commentManager.create(issue, currentUser, "Les droits ont bien été appliqués", false)