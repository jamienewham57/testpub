import com.atlassian.jira.bc.project.component.ProjectComponent
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.project.Project
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.project.Project
import com.atlassian.jira.issue.customfields.manager.OptionsManager
 
cf = ComponentAccessor.customFieldManager.getCustomFieldObjectByName("Field Name")
optionsManager = componentManager.getComponentInstanceOfType(OptionsManager.class)
cf2 = ComponentAccessor.customFieldManager.getCustomFieldObjects(issue).find{it.name =='Name of Field'}
val = issue.getCustomFieldValue(cf)
if(val.contains("mandg.otc.notifications")){
    Project project = issue.getProjectObject()
    ProjectComponent component = ComponentAccessor.getProjectComponentManager().findByComponentName(project.getId(), "Component Name")
    issue.setComponentObjects([component])
    def fieldConfig = cf2.getRelevantConfig(issue)
    def option = optionsManager.getOptions(fieldConfig).find {it.value == "Field Value"}
    issue.setCustomFieldValue(cf2, option)
     
} else if (val.contains("EUC_OTC_Trade_Tickets")){
    Project project = issue.getProjectObject()
    ProjectComponent component = ComponentAccessor.getProjectComponentManager().findByComponentName(project.getId(), "Component Name")
    issue.setComponentObjects([component])
    def fieldConfig = cf2.getRelevantConfig(issue)
    def option = optionsManager.getOptions(fieldConfig).find {it.value == "Field Value"}
    issue.setCustomFieldValue(cf2, option)
} else {
 
File sourceFile = new File("location/of/file/summary_rule1.groovy")
Class groovyClass = new GroovyClassLoader(getClass().getClassLoader()).parseClass(sourceFile)
GroovyObject myObject = (GroovyObject) groovyClass.newInstance();
 
}