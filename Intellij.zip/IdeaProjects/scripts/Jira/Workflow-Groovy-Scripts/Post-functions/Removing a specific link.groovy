import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.link.IssueLinkManager
import com.atlassian.jira.security.JiraAuthenticationContext
import com.atlassian.crowd.embedded.api.User
 
JiraAuthenticationContext authContext = ComponentAccessor.getJiraAuthenticationContext()
User user = authContext.getLoggedInUser()
 
def componentManager = ComponentManager.getInstance()
def issueLinkManager = componentManager.getIssueLinkManager()
 
issueLinkManager.getOutwardLinks(issue.id).each {issueLink ->             
                linkedIssue = issueLink.destinationObject  
                 issueLink = issueLinkManager.getIssueLink(issue.id, linkedIssue.id, 11000) //11000 is the ID of my link
    if (issueLink){    issueLinkManager.removeIssueLink(issueLink, user)}
                 }