import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.user.UserEventType
import com.atlassian.crowd.embedded.api.User
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.ComponentManager
 
ComponentManager componentManager = ComponentManager.getInstance()
def userUtil = ComponentAccessor.getUserUtil()
def commentManager = ComponentAccessor.getCommentManager()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def currentUser = componentManager.jiraAuthenticationContext?.user
 
def field1 = customFieldManager.getCustomFieldObject("customfield_XXXXX")
def field1val = issue.getCustomFieldValue(field1)
 
def field2 = customFieldManager.getCustomFieldObject("customfield_XXXXX")
def field2val = issue.getCustomFieldValue(field2)
 
Issue issue  = issue
def id=issue.getId()
 
commentManager.create(issue, currentUser, "Fields generated\nField1: " + field1val + "\nField2: " + field2val, false)