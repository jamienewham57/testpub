import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.user.UserEventType
import com.atlassian.jira.user.ApplicationUser
 
  
def userUtil = ComponentAccessor.getUserUtil()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def commentManager = ComponentAccessor.getCommentManager()
def issueManager = ComponentAccessor.getIssueManager()
def currentUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
def nomCf = customFieldManager.getCustomFieldObject("customfield_XXXXX")
def prenomCf = customFieldManager.getCustomFieldObject("customfield_XXXXY")
def emailCf = customFieldManager.getCustomFieldObject("customfield_XXXXZ")
def String nom = issue.getCustomFieldValue(nomCf)
def String prenom = issue.getCustomFieldValue(prenomCf)
def String email = issue.getCustomFieldValue(emailCf)
def String matricule = prenom+"."+nom
 
 
if(matricule == null || nom == null || prenom == null || email == null) {
commentManager.create(issue, currentUser, "Erreur : un ou plusieurs paramètres d'entrée sont vides.\n\nMatricule : " + matricule + "\nNom : " + nom + "\nPrénom : " + prenom + "\nEmail : " + email, false)
return
}
 
if(userUtil.userExists(matricule)) {
commentManager.create(issue, currentUser, "Erreur : un compte existe déjà avec ce matricule.\n\nMatricule : " + matricule + "\nNom : " + nom + "\nPrénom : " + prenom + "\nEmail : " + email, false)
return
}
 
ApplicationUser user = userUtil.createUserWithNotification(matricule, "", email, prenom + " " + nom.toUpperCase(), UserEventType.USER_CREATED)
 
if(user != null) {
userUtil.addToJiraUsePermission(user)
commentManager.create(issue, currentUser, "L'utilisateur a été créé, un mail a été envoyé pour initialiser le mot de passe.", false)
return
} else {
commentManager.create(issue, currentUser, "Erreur : la création a échouée, consultez les logs de l'application.\n\nMatricule : " + matricule + "\nNom : " + nom + "\nPrénom : " + prenom + "\nEmail : " + email, false)
return
}