import com.atlassian.jira.bc.project.component.ProjectComponent
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.project.Project
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.project.Project
import com.atlassian.jira.issue.customfields.manager.OptionsManager
 
optionsManager = componentManager.getComponentInstanceOfType(OptionsManager.class)
cf2 = ComponentAccessor.customFieldManager.getCustomFieldObjects(issue).find{it.name =='Field Name'}
String[] words = issue.getSummary().split("All the key words")
for(int i = 0 ; i < words.length ; i++) {
if(words[i].contains("keyword from above")) {
    Project project = issue.getProjectObject()
    ProjectComponent component = ComponentAccessor.getProjectComponentManager().findByComponentName(project.getId(), "Field Value")
    issue.setComponentObjects([component])
    def fieldConfig = cf2.getRelevantConfig(issue)
    def option = optionsManager.getOptions(fieldConfig).find {it.value == "Field Value"}
    issue.setCustomFieldValue(cf2, option)
} else if (words[i].contains("keyword from above")) {
    Project project = issue.getProjectObject()
    ProjectComponent component = ComponentAccessor.getProjectComponentManager().findByComponentName(project.getId(), "Component Name")
    issue.setComponentObjects([component])
    def fieldConfig = cf2.getRelevantConfig(issue)
    def option = optionsManager.getOptions(fieldConfig).find {it.value == "Field Value"}
    issue.setCustomFieldValue(cf2, option)
}else {
    Project project = issue.getProjectObject()
    ProjectComponent component = ComponentAccessor.getProjectComponentManager().findByComponentName(project.getId(), "Component Name")
    issue.setComponentObjects([component])
}
}