import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def serviceproviderf = customFieldManager.getCustomFieldObject('customfield_16276')
def serviceuserf = customFieldManager.getCustomFieldObject('customfield_17408')
def serviceproviderv = issue.getCustomFieldValue(serviceproviderf).toString()
def userUtil =  ComponentAccessor.getUserUtil()
def userManager = ComponentAccessor.getUserManager()
def user = userManager.getUserByName(serviceproviderv)
if (user) {
issue.setCustomFieldValue(serviceuserf, user)
}