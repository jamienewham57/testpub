//PF = Set Field Value to constant or Groovy expression
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.security.Permissions
  
def componentManager = ComponentManager.getInstance()
def currentUser = componentManager.jiraAuthenticationContext?.user
return currentUser