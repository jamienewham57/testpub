import com.atlassian.crowd.embedded.api.Group;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.user.ApplicationUser;
import com.atlassian.jira.user.util.UserManager;
import com.atlassian.jira.user.util.UserUtil;
import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.config.util.JiraHome;
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.IssueManager
import org.apache.log4j.Category
import com.atlassian.jira.issue.attachment.Attachment
import com.atlassian.jira.issue.AttachmentManager
import com.atlassian.jira.config.util.AttachmentPathManager
import com.atlassian.jira.issue.attachment.FileAttachments
import com.atlassian.jira.security.JiraAuthenticationContext
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.IssueInputParameters
import com.atlassian.jira.bc.issue.IssueService
import com.atlassian.jira.bc.issue.IssueService.IssueResult
import com.atlassian.jira.bc.issue.IssueService.CreateValidationResult
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.issue.search.SearchProvider
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.search.SearchResults
import com.atlassian.jira.issue.index.IssueIndexingService
  
    
//definition of logs
Category log = Category.getInstance("com.onresolve.jira.groovy")
log.setLevel(org.apache.log4j.Level.DEBUG)
  
//definition of my class
class MyClass{
    String column1;
    String column2;
      
    //Surcharge of method equals
    public boolean equals(MyClass objet) {
        return objet.column1.equals(this.column1) && objet.column2.equals(this.column2);
    }
      
}
MyClass monObjet = new MyClass();
Set<MyClass> listObj = new HashSet<MyClass>();
  
    
//definition of managers
IssueManager issueManager = ComponentAccessor.getIssueManager()
AttachmentManager attachmentManager = ComponentAccessor.getAttachmentManager()
AttachmentPathManager attachmentPathManager = ComponentAccessor.getAttachmentPathManager()
JiraAuthenticationContext authenticationContext = ComponentAccessor.getJiraAuthenticationContext();
IssueService issueService = ComponentAccessor.getComponent(IssueService);
SearchService searchService = ComponentAccessor.getComponent(SearchService.class)
IssueIndexingService issueIndexingService = (IssueIndexingService) ComponentAccessor.getComponent(IssueIndexingService.class)
  
    
    
//definition of variables
//Issue issue
List<Attachment> listAttachments
List<MutableIssue> listIssue
List<MutableIssue> listResults
List<MutableIssue> listResults2
String fileName
Long attId
String projectKey
String issueKey
String fileId
String path
String issueType
String jira_home
String JQLsearch
ApplicationUser user
IssueInputParameters issueParameters
CreateValidationResult validationResult
IssueResult issueResult
File attachment
  
   
   
//set of variables
//issue = issueManager.getIssueByCurrentKey("SR-33")
listAttachments = new ArrayList<Attachment>();
listIssue = new ArrayList<MutableIssue>();
listResults = new ArrayList<MutableIssue>();
listResults2 = new ArrayList<MutableIssue>();
listAttachments = attachmentManager.getAttachments(issue)
fileName = listAttachments[0].getFilename()
attId = listAttachments[0].getId()
projectKey = issue.getProjectObject().getKey()
issueKey = issue.getKey()
fileId = FileAttachments.computeIssueBucketDir(issueKey)
path = attachmentPathManager.getAttachmentPath()
issueType ="10001";
user = authenticationContext.getLoggedInUser();
  
   
//debug
log.debug(path)
log.debug(projectKey)
log.debug(fileId)
log.debug(issueKey)
   
  
//creation full path to attachment
jira_home = path + "\\" + projectKey + "\\" + fileId + "\\" + issueKey + "\\"
log.debug("full path to attachment: " + jira_home)
   
  
//creation of the file needed
attachment = new File(jira_home + attId)
   
  
//beginning of treatment
attachment.splitEachLine(";"){ line ->
    log.debug(line)
      
    //set of my class parameters
    monObjet.column1 = line[0]
    monObjet.column2 = line[1]
  
    //verifying that my list hasn't the combination tested just before
    if(!listObj.contains(monObjet)){
          
    //creation of a JQL filter using values of the csv
    JQLsearch = 'issuetype = ' + line[0] + ' AND summary ~ "' + line[1] + '"'
    SearchService.ParseResult parseResult =  searchService.parseQuery(user, JQLsearch)
    //checking the JQL is valid
        if (parseResult.isValid()) {
            SearchResults searchResult = searchService.search(user, parseResult.getQuery(), PagerFilter.getUnlimitedFilter())
            listResults = searchResult.issues.collect {issueManager.getIssueObject(it.id)}
            log.debug("JQL Search: " + JQLsearch)
            log.debug("Results of my JQL Search: " + listResults )
            //For every issues found in filters result
            //Stock it in a list
            for(MutableIssue issueSearch:listResults){
                log.debug("issue: " + issueSearch.getKey())
                listIssue.add(issueSearch)
                }
                //Debug, display the complete list
                log.debug("This is my list: " + listIssue)
        }
        else {
        log.error("Invalid JQL: " + JQLsearch)
        }
  
        //set of issue parameters
        issueParameters = issueService.newIssueInputParameters(); 
        issueParameters.setSkipScreenCheck(true);
        issueParameters.setProjectId(issue.getProjectId());
        issueParameters.setReporterId(user.getUsername());
        issueParameters.setIssueTypeId(issueType);
        issueParameters.setSummary(line[1]);
        issueParameters.setDescription(line[1]);
        //check if issue creation is possible
        validationResult = issueService.validateCreate(user, issueParameters)
  
        //condition if my query is empty
        if(listResults.isEmpty() && validationResult.isValid()){
            //add the combination of this search in my list
            listObj.add(monObjet)
            //Creation of an issue with parameters in csv
            issueResult = issueService.create(user, validationResult)
            issueIndexingService.reIndex(issueResult.getIssue())   
            log.debug("issue created summary: " + issueResult.getIssue().getSummary())
            }
         else{
            log.debug"INVALID"
            }
    }                
}
    
return