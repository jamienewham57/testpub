import com.atlassian.crowd.embedded.api.CrowdService
import com.atlassian.crowd.embedded.api.UserWithAttributes
import com.atlassian.crowd.embedded.impl.ImmutableUser
import com.atlassian.jira.bc.user.UserService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.user.ApplicationUsers
import com.atlassian.jira.user.util.UserUtil
import com.atlassian.crowd.embedded.api.User
import com.atlassian.jira.user.DelegatingApplicationUser
 
   
UserUtil userUtil = ComponentAccessor.userUtil
CrowdService crowdService = ComponentAccessor.crowdService
UserService userService = ComponentAccessor.getComponent(UserService)
ApplicationUser updateUser
UserService.UpdateUserValidationResult updateUserValidationResult
 
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def currentUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
def commentManager = ComponentAccessor.getCommentManager()
 
def userCf = customFieldManager.getCustomFieldObject("customfield_XXXXX")
def ApplicationUser user = issue.getCustomFieldValue(userCf) as ApplicationUser
 
 
updateUser = ApplicationUsers.from(ImmutableUser.newUser(ApplicationUsers.toDirectoryUser(user)).active(false).toUser())
updateUserValidationResult = userService.validateUpdateUser(updateUser)
if (updateUserValidationResult.isValid()) {
     userService.updateUser(updateUserValidationResult)
     commentManager.create(issue, currentUser, "L'utilisateur ${updateUser.name} a désactivé", false)
} else {
     commentManager.create(issue, currentUser, "L'utilisateur ${updateUser.name} a n'a pas été désactivé", false)
     log.error "Update of ${user.name} failed: ${updateUserValidationResult.getErrorCollection().getErrors().entrySet().join(',')}"
}