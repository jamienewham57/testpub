import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.IssueInputParameters
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.bc.issue.IssueService.CreateValidationResult
import com.atlassian.jira.bc.issue.IssueService.IssueResult
import org.apache.log4j.Category
  
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG);
log.debug "Start PostFunction =====> createSubTaskOnParent.groovy";
def functionSubCreation (Issue parentIssue, IssueInputParameters issueParams, String reporter){
     
    log.debug("Start of creatation");
    //Manager
    def issueService = ComponentAccessor.getIssueService();
    def userManager = ComponentAccessor.getUserManager();
    def issueLinkManager = ComponentAccessor.getIssueLinkManager();
         
    //Users
    def user_for_treatment = userManager.getUserObject(reporter);
    //Variable
    IssueResult createResult = null;
    CreateValidationResult validationResult = null;
    MutableIssue issueCreated = null;
    def issueLinkId = 10100; //default sub task link ID
    // Check if creation is possible
    validationResult = issueService.validateSubTaskCreate(user_for_treatment, parentIssue.getId(), issueParams);
        if (validationResult.isValid()) {
            //If OK, start of creation
            log.debug("Start of creation" );
            createResult = issueService.create(user_for_treatment, validationResult);
            issueCreated = createResult.getIssue();
            Collection<Issue> subTaskLinked = parentIssue.getSubTaskObjects();
            def sequenceNumber = 0;
            if (subTaskLinked.size()>0){
                sequenceNumber = subTaskLinked.size();
            }
            issueLinkManager.createIssueLink(parentIssue.id, issueCreated.id, issueLinkId,sequenceNumber, user_for_treatment);
            log.debug("End of creatation, issue :" + issueCreated.getKey() + " is created" );
        }
        else {
        //If KO, stop
            log.debug "validationResult errors :" + validationResult.getErrorCollection().toString();
        }
}
//UC
def issueService = ComponentAccessor.getIssueService();
IssueInputParameters issueParameters = issueService.newIssueInputParameters();
//Get Parent Issue
Issue parentIssue = issue.getParentObject();
log.debug "Parent Issue : "+parentIssue.summary;
String defaultReporter = "admin";
String defaultSummary = "Summary of the created sub-task"
String defaultIssueType = "5";
String defaultStatusId = "1";
// define subtask
issueParameters.setSkipScreenCheck(true);
issueParameters.setProjectId(parentIssue.getProjectId());
issueParameters.setIssueTypeId(defaultIssueType);
issueParameters.setSummary(defaultSummary);
issueParameters.setReporterId(parentIssue.getReporterId());
issueParameters.setAssigneeId(parentIssue.getAssigneeId());
issueParameters.setStatusId(defaultStatusId);
//Call the function
functionSubCreation(parentIssue, issueParameters, defaultReporter);
log.debug "End PostFunction =====> createSubTaskOnParent.groovy";