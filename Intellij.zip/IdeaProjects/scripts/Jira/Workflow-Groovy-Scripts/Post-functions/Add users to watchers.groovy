import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.component.ComponentAccessor
  
ComponentManager componentManager = ComponentManager.getInstance()
def watcherManager = ComponentAccessor.getWatcherManager()
def userManager = ComponentAccessor.getUserManager()
def user1 = userManager.getUserObject("sirot_x")
def user2= userManager.getUserObject("nguyen_r")
def user3= userManager.getUserObject("hamdi_f")
  
if (user1) watcherManager.startWatching(user1, issue.genericValue)
if (user2) watcherManager.startWatching(user2, issue.genericValue)
if (user3) watcherManager.startWatching(user3, issue.genericValue)