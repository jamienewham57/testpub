import com.atlassian.crowd.embedded.api.Group
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.customfields.manager.OptionsManager
import org.apache.log4j.Category
 
//add details to log file
def Category log = Category.getInstance("com.onresolve.jira.groovy.PostFunction")
log.setLevel(org.apache.log4j.Level.DEBUG)
log.debug "debug statements"
 
ComponentManager componentManager = ComponentManager.getInstance()
optionsManager = componentManager.getComponentInstanceOfType(OptionsManager.class)
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
 
//get groups
Group group1 = componentManager.getUserUtil().getGroup("groupname1")
Group group2 = componentManager.getUserUtil().getGroup("groupname2")
 
//get group field
def cf = customFieldManager.getCustomFieldObjects(issue).find {it.id == 'customfield_XXXXX'}
 
//create list for the group
List<Group> groupList = new ArrayList<Group>()
 
//get Select list Value
cf2 = ComponentAccessor.customFieldManager.getCustomFieldObjects(issue).find{it.id =='customfield_XXXXX'}
def selval = issue.getCustomFieldValue(cf2)
 
//get Select List Options
def fieldConfig = cf2.getRelevantConfig(issue)
def option1 = optionsManager.getOptions(fieldConfig).find {it.value == "Option1"}
def option2 = optionsManager.getOptions(fieldConfig).find {it.value == "Option2"}
 
//get Cascading Select List
cf3 = ComponentAccessor.customFieldManager.getCustomFieldObject('customfield_XXXXX')
Map casval = issue.getCustomFieldValue(cf3) as Map
 
//get Cascading Select List Options according to parent and child
    String first = casval.get(null)
    String second = casval.get("1")
    log.debug("First: " + first + "Second: " + second)
 
//update the group field
if(selval == option1 && first == 'ParentValue' && second == 'ChildValue'){
groupList.add(group1)
issue.setCustomFieldValue(cf, groupList)
    }
else if (selval == option2 && first == 'ParentValue' && second == 'ChildValue'){
groupList.add(group2)
issue.setCustomFieldValue(cf, groupList)
    }