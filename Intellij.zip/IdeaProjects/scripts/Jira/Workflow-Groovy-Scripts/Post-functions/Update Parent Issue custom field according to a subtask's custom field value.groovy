import org.apache.log4j.Category
import com.atlassian.crowd.embedded.api.User
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.util.IssueChangeHolder
import com.opensymphony.workflow.InvalidInputException
 
 
MutableIssue mutableIssue = issue;
MutableIssue parentIssue = mutableIssue.getParentObject();
 
ComponentManager componentManager = ComponentManager.getInstance();
CustomFieldManager customFieldManager = componentManager.getCustomFieldManager();
 
IssueChangeHolder changeHolder = new DefaultIssueChangeHolder();
 
String customFieldName = "customfield_10203";
double total = 0;
double oldParentValue = 0;
double subTaskSizingValue = 0;
double newParentSizingValue = 0;
CustomField cf = customFieldManager.getCustomFieldObject(customFieldName);
 
String parentCustomFieldValue = parentIssue.getCustomFieldValue(cf).toString();
String subTaskCustomFieldValue = mutableIssue.getCustomFieldValue(cf).toString();
oldParentValue= Double.parseDouble(parentCustomFieldValue.toString());
subTaskSizingValue = Double.parseDouble(subTaskCustomFieldValue.toString());
newParentSizingValue = oldParentValue - subTaskSizingValue;
 
cf.updateValue(null, mutableIssue, new ModifiedValue(parentIssue.getCustomFieldValue(cf), total), changeHolder);
cf.updateValue(null, parentIssue, new ModifiedValue(parentIssue.getCustomFieldValue(cf), newParentSizingValue), changeHolder);