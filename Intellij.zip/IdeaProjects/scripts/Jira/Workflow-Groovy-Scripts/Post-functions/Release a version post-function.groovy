import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.project.version.VersionManager
import com.atlassian.jira.project.version.Version
import java.util.Date
def versionManager = ComponentAccessor.versionManager;
versionManager.getAffectedVersionsFor(issue)?.each {Version ver ->
    if(!ver.released) {
        versionManager.releaseVersion(ver, true)
        ver.releaseDate = new Date()
        versionManager.update(ver)
    }
}