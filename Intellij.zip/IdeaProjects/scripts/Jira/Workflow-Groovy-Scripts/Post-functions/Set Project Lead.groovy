import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.user.ApplicationUsers
import com.atlassian.jira.project.Project
 
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def projectCf = customFieldManager.getCustomFieldObject("customfield_XXXXX")
def Project project = issue.getCustomFieldValue(projectCf) as Project
def projectManager = project.getProjectLead()
 
issue.setAssignee(projectManager);