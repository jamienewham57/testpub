import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.comments.CommentManager
import com.opensymphony.workflow.WorkflowContext
import org.apache.log4j.Category
  
String currentUser = ((WorkflowContext) transientVars.get("context")).getCaller();
commmgr = (CommentManager) ComponentManager.getComponentInstanceOfType(CommentManager.class)
commmgr.create(issue, currentUser, "I resolved this issue even though there are unresolved sub-tasks... slapped wrists", true)
issue.store()