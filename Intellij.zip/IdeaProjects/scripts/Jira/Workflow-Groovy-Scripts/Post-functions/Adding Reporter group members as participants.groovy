import com.atlassian.jira.ComponentManager
import com.atlassian.jira.security.groups.GroupManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.user.ApplicationUser
def customFieldManager = ComponentAccessor.getCustomFieldManager()
GroupManager groupManager = ComponentManager.getComponentInstanceOfType(GroupManager.class)
//getting the list of every groups of the reporter
def GroupList = groupManager.getGroupNamesForUser(issue.getReporterId())
def values = GroupList.toString()
//getting only groups matching with the naming convention chosen
def result = (GroupList =~ /support-[\w]+/)
def reporterGroup = result[0].toString()
log.debug("the group name is : " + reporterGroup)
def memberManager = ComponentAccessor.getGroupManager()
//checking if the group exist
if (groupManager.getGroup(reporterGroup)){
    //getting list of users belonging to this group
    def getUsersAsArray = {
        def users = memberManager.getUserNamesInGroup(reporterGroup)
        def userManager = ComponentAccessor.getUserUtil()
        ArrayList<ApplicationUser> userList = new ArrayList<ApplicationUser>()
        users.each {
            def user = userManager.getUserByName(it)
            if(user)
            { userList.add(user) }
        }
        return userList
    }
    //getting the participant field
    def requestParticipantsField = customFieldManager.getCustomFieldObject("customfield_10011")
    //adding users as request participants
    MutableIssue myIssue = issue
    ArrayList<ApplicationUser> applicationUsers = getUsersAsArray()   
    myIssue.setCustomFieldValue(requestParticipantsField, applicationUsers)}