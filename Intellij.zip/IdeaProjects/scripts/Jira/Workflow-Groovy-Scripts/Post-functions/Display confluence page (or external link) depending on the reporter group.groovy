import com.atlassian.jira.ComponentManager
import com.atlassian.jira.security.groups.GroupManager
GroupManager groupManager = ComponentManager.getComponentInstanceOfType(GroupManager.class)
GroupList = groupManager.getGroupsForUser(issue.getReporterId()).name;
company = GroupList[0]
switch (company) {
   
case "company 1":
link = "http://link to company1.com"
break
  
case "company 2":
link = "http://link to company2.com"
break
  
default:
return null;
}
return link;