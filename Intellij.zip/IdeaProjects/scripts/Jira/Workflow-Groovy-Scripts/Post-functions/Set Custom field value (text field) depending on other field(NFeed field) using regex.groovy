import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.ManagerFactory
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def changeHolder = new DefaultIssueChangeHolder()
def locationf = customFieldManager.getCustomFieldObject('customfield_10205')
def location = issue.getCustomFieldValue(locationf).toString()
def originf = customFieldManager.getCustomFieldObject('customfield_10239')
if (issue.getCustomFieldValue(originf) == null){
    if (location ==~ /^\[CH.*/ || location ==~ /^FR.*/){
        originf.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(originf), "emea@emea.emea"),changeHolder)
         issue.store()
    } else if (location ==~ /^UK.*/){
        originf.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(originf), "uk@uk.uk"),changeHolder)
         issue.store()
    } else if (location ==~ /^US.*/) {
        originf.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(originf), "us@us.us"),changeHolder)
         issue.store()
    } else if (location ==~ /^[0-9]{4}.*/) {
        originf.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(originf), "store@store.store"),changeHolder)
         issue.store()
    } else {issue.summary = location}
} else { issue.summary = "["+issue.getKey()+"]"+ " " + issue.getSummary()}