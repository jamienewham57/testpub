import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.project.version.VersionManager
import com.atlassian.jira.project.version.Version
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
 
def issueLinkManager = ComponentAccessor.issueLinkManager
def issueManager = ComponentAccessor.issueManager
def customFieldManager = ComponentAccessor.customFieldManager
def currentUser = ComponentAccessor.jiraAuthenticationContext?.user
 
MutableIssue issue = issue
 
CustomField buildIssue = customFieldManager.getCustomFieldObject("customfield_11202")
 
if(buildIssue != null) {
    def selectedBuildIssueString = issue.getCustomFieldValue(buildIssue)?.iterator()?.next()
    if(selectedBuildIssueString != null) {
        def selectedBuildIssue = selectedBuildIssueString.toLong()
        if(selectedBuildIssue != null) {
            issueLinkManager.createIssueLink(issue.id,selectedBuildIssue,10001,0,currentUser.directoryUser)
        }
    }
}