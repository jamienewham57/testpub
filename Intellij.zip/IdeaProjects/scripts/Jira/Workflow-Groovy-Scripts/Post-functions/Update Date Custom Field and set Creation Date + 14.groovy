import org.apache.log4j.Category
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.customfields.manager.OptionsManager
ComponentManager componentManager = ComponentManager.getInstance()
def customField = ComponentAccessor.customFieldManager.getCustomFieldObjectByName("Due Date Report Production")
issue.setCustomFieldValue(customField, issue.getCreated() + 14)
issue.store()