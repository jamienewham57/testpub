import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.ManagerFactory
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def changeHolder = new DefaultIssueChangeHolder()
def customer_request_f = customFieldManager.getCustomFieldObject('customfield_10000')
def customer_request_v = (String)issue.getCustomFieldValue(customer_request_f)
  
def text_field_f = customFieldManager.getCustomFieldObject('customfield_11229')
  
text_field_f.updateValue(null,
 issue, new ModifiedValue(issue.getCustomFieldValue(text_field_f),
customer_request_v),changeHolder)
  
issue.store()