import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.bc.project.component.ProjectComponent
import com.atlassian.jira.bc.project.component.ProjectComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
def componentManager = ComponentAccessor.projectComponentManager
def issueManager = ComponentAccessor.issueManager
def customFieldManager = ComponentAccessor.customFieldManager
MutableIssue issue = issue
CustomField nFeedComponent = customFieldManager.getCustomFieldObject("customfield_?????")
if(nFeedComponent != null) {
    def selectedComponentString = issue.getCustomFieldValue(nFeedComponent)?.iterator()?.next()
    def selectedComponent = componentManager.find(selectedComponentString.toLong())
    if(selectedComponent != null) {
        ArrayList<ProjectComponent> componentsList = new ArrayList<ProjectComponent>()
        componentsList.add(selectedComponent)
        issue.setComponentObjects(componentsList)
    }
}