/*
In this script it's only if the fix version doesn't contain Candidates or is not empty

*/

import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.ManagerFactory
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
 
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def changeHolder = new DefaultIssueChangeHolder()
//getting my number field
def noReschedule = customFieldManager.getCustomFieldObject('customfield_12135')
//getting my condition on this field
def previousRelease = customFieldManager.getCustomFieldObject('customfield_12801')
def release = issue.getCustomFieldValue(previousRelease).toString()
//adding my condition
if (release != null && !(release =~ /[\w\s\d]+\sCandidates]$/) ){
def increase = issue.getCustomFieldValue(noReschedule)
//increasing my number field
Double  increased = (Double) increase+1
//applying the result in my CF
noReschedule.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(noReschedule), increased),changeHolder)
issue.store()
}