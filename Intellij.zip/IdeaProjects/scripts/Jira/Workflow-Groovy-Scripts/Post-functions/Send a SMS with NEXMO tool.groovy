import com.atlassian.jira.issue.issuetype.IssueType
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import org.apache.log4j.Category
import com.atlassian.jira.issue.Issue
  
Category log = log;
log.setLevel(org.apache.log4j.Level.DEBUG);
log.debug("Sending SMS start")
// If Incident
Issue issue = event.getIssue()
CustomFieldManager cFManager = ComponentAccessor.getCustomFieldManager()
CustomField cfSeverity = cFManager.getCustomFieldObject('customfield_10063')
IssueType issueType = issue.getIssueType()
if (issueType.name.equals("Incident")){
   // If S1 or S2
    if (cfSeverity.getValue(issue).toString().equals('S1') || cfSeverity.getValue(issue).toString().equals('S2')) {
        String getHttpURL = "https://rest.nexmo.com/sms/json?api_key=id_api_key&api_secret=password_api_key&from=JIRA+SD&to=33689948910&text=New+Incident+OPEN.+Incident+"+issue.key+"+Severity+"+cfSeverity.getValue(issue).toString()
        log.debug("SMS sent to 33689948910 for Incident P1 P2")
        new URL(getHttpURL).getText()
    }
}