import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def CEDf = customFieldManager.getCustomFieldObject('customfield_10226')
log.warn("issue.assignee : " + issue.assignee)
log.warn("originalIssue.assignee : " + originalIssue.assignee)
issue.assignee == originalIssue.assignee && issue.getCustomFieldValue(CEDf) != originalIssue.getCustomFieldValue(CEDf)