import com.atlassian.jira.ComponentManager 
import com.atlassian.jira.ManagerFactory 
import com.atlassian.jira.issue.security.IssueSecurityLevelManager 
import com.atlassian.jira.issue.security.IssueSecuritySchemeManager  
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.project.component.ProjectComponent;
import com.atlassian.jira.bc.project.component.ProjectComponentManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueFactory;
     
   
  if(issue.assignee.name==("JD-TMA-EURO"))
    {
        issue.setSecurityLevelId(10101) 
    }
  else if(issue.assignee.name==("JD-TMA-IPSO"))
   {
    issue.setSecurityLevelId(10100) 
    }
else if(issue.assignee.name==("JD-TMA-PORG"))
   {
    issue.setSecurityLevelId(10102) 
    }
  issue.store()