import com.atlassian.jira.ComponentManager
import com.atlassian.jira.event.type.EventDispatchOption
import com.atlassian.jira.issue.MutableIssue
import org.apache.log4j.Category
log = Category.getInstance("com.onresolve.jira.groovy.CustomWorkLogUpdater.groovy")
def componentManager = ComponentManager.getInstance()
def issueLinkManager = componentManager.getIssueLinkManager()
def issueManager = componentManager.getIssueManager()
// REMAINING TIME COMPUTATION
totalRemaining = 0l
issueLinkManager.getOutwardLinks(issue.id).each {issueLink ->
if (issueLink.issueLinkType.name == "Decomposition") {
def linkedIssue = issueLink.destinationObject
if(linkedIssue.getEstimate() != null) {
totalRemaining += linkedIssue.getEstimate()
}
}
}
// TIME SPENT COMPUTATION
totalSpent = 0l
isScanned = []
def MY = { IssueId ->
def myIssueLinks = issueLinkManager.getOutwardLinks(IssueId)
myIssueLinks.each {issueLink ->
if (issueLink.issueLinkType.name == "Decomposition") {
def myLinkedIssue = issueLink.destinationObject
def myLinkedIssueId = myLinkedIssue.getId()
if (!isScanned.contains(myLinkedIssueId)){
if(myLinkedIssue.getTimeSpent()!=null) {
totalSpent += myLinkedIssue.getTimeSpent()
}
isScanned << myLinkedIssueId
owner.call(myLinkedIssueId)
}
}
}
}
isScanned << issue.id
MY.call(issue.id)
　
MutableIssue myIssue = issue
myIssue.setTimeSpent(totalSpent)
myIssue.setEstimate(totalRemaining)
issueManager.updateIssue(myIssue.getAssignee(), myIssue, EventDispatchOption.DO_NOT_DISPATCH, false);