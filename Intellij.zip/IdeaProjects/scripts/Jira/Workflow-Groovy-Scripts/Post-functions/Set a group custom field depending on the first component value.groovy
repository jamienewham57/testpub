import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.ComponentManager
import com.atlassian.crowd.embedded.api.Group
import com.atlassian.jira.security.groups.GroupManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.event.issue.IssueEvent
import org.apache.log4j.Level
import org.apache.log4j.Logger
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
GroupManager groupManager = ComponentManager.getComponentInstanceOfType(GroupManager.class)
def changeHolder = new DefaultIssueChangeHolder()
def componentName = issue.getComponentObjects().getAt(0).getName()
String componentgroup = "EO-"+ componentName +"-Usergroup"
 
//create list for the group
List<Group> groupList = new ArrayList<Group>()
 
if (groupManager.groupExists(componentgroup.toString())){
    //get groups
    def group1 = groupManager.getGroup(componentgroup)
    groupList.add(group1)
    def cfGroupPicker = ComponentAccessor.customFieldManager.getCustomFieldObject("customfield_14704")
    cfGroupPicker.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(cfGroupPicker), groupList),changeHolder)
    log.info("Issue has been updated")
}