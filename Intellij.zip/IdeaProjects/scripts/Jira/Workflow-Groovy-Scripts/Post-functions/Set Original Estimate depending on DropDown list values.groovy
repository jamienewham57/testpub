import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.ManagerFactory
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def sizef = customFieldManager.getCustomFieldObject('customfield_12403')
def size = issue.getCustomFieldValue(sizef).toString()
def issuecategory = issue.getProjectObject().getProjectCategory().getName()
Long oe = issue.originalEstimate
if (issuecategory =~ /EO+/) {
    if (size == "XS"){
        issue.setOriginalEstimate((Long) 8*3600)
        }
    else if (size == "S"){
         issue.setOriginalEstimate((Long)16*3600)
        }
    else if (size == "M"){
        def estimate = (Long) 32*3600
    issue.setOriginalEstimate(estimate)
        }
    else if (size == "L"){
        def estimate = (Long) 64*3600
    issue.setOriginalEstimate((Long) 64*3600)
        }
    else if (size == "XL"){
        def estimate = (Long) 128*3600
    issue.setOriginalEstimate(estimate)
        }
    else if (size == "XXL"){
        def estimate = (Long) 256*3600
    issue.setOriginalEstimate(estimate)
        }
    else if (size == "XXXL"){
        def estimate = (Long) 512*3600
    issue.setOriginalEstimate(estimate)
        }
    else if (size == "XXXXL"){
        def estimate = (Long) 1024*3600
    issue.setOriginalEstimate(estimate)
    }else if (size == "No Effort"){
        issue.setOriginalEstimate((Long) 0)
    }
} else if (issuecategory =~ /NA+/) {
    if (size == "XS"){
        issue.setOriginalEstimate((Long) 4*3600)
    } else if (size == "S"){
        issue.setOriginalEstimate((Long) 16*3600)
    } else if (size == "M"){
        issue.setOriginalEstimate((Long) 60*3600)
    } else if (size == "L"){
        issue.setOriginalEstimate((Long) 220*3600)
    } else if (size == "XL"){
        issue.setOriginalEstimate((Long) 700*3600)
    }else if (size == "No Effort"){
        issue.setOriginalEstimate((Long) 0)
    }
} else if (issuecategory =~ /Demo+/) {
    if (size == "XS"){
        issue.setOriginalEstimate((Long) 4*3600)
    } else if (size == "S"){
        issue.setOriginalEstimate((Long) 16*3600)
    } else if (size == "M"){
        issue.setOriginalEstimate((Long) 60*3600)
    } else if (size == "L"){
        issue.setOriginalEstimate((Long) 220*3600)
    } else if (size == "XL"){
        issue.setOriginalEstimate((Long) 700*3600)
    }else if (size == "No Effort"){
        issue.setOriginalEstimate((Long) 0)
    }
}