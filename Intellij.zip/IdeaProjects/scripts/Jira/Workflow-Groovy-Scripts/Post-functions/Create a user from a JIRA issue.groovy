import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.event.user.UserEventType
import com.atlassian.crowd.embedded.api.User
 
def userUtil = ComponentAccessor.getUserUtil()
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def commentManager = ComponentAccessor.getCommentManager()
def issueManager = ComponentAccessor.getIssueManager()
def currentUser = componentManager.jiraAuthenticationContext?.user
def issue = issueManager.getIssueObject("AJIR-226")
def matriculeCf = customFieldManager.getCustomFieldObject("customfield_11800")
def nomCf = customFieldManager.getCustomFieldObject("customfield_11801")
def prenomCf = customFieldManager.getCustomFieldObject("customfield_11802")
def emailCf = customFieldManager.getCustomFieldObject("customfield_10114")
def matricule = issue.getCustomFieldValue(matriculeCf)
def nom = issue.getCustomFieldValue(nomCf)
def prenom = issue.getCustomFieldValue(prenomCf)
def email = issue.getCustomFieldValue(emailCf)
if(matricule == null || nom == null || prenom == null || email == null) {
    commentManager.create(issue, currentUser, "Erreur : un ou plusieurs paramètres d'entrée sont vides.\n\nMatricule : " + matricule + "\nNom : " + nom + "\nPrénom : " + prenom + "\nEmail : " + email, false)
    return;
}
if(userUtil.userExists(matricule)) {
    commentManager.create(issue, currentUser, "Erreur : un compte existe déjà avec ce matricule.\n\nMatricule : " + matricule + "\nNom : " + nom + "\nPrénom : " + prenom + "\nEmail : " + email, false)
    return;
}
User user = userUtil.createUserWithNotification(matricule, "", email, prenom + " " + nom.toUpperCase(), UserEventType.USER_CREATED)
if(user != null) {
    userUtil.addToJiraUsePermission(user)
    commentManager.create(issue, currentUser, "L'utilisateur a été créé, un mail a été envoyé pour initialiser le mot de passe.", false)
    return;
} else {
    commentManager.create(issue, currentUser, "Erreur : la création a échouée, consultez les logs de l'application.\n\nMatricule : " + matricule + "\nNom : " + nom + "\nPrénom : " + prenom + "\nEmail : " + email, false)
    return;
}