<%
def commentManager = com.atlassian.jira.component.ComponentAccessor.getCommentManager()
def comments = commentManager.getComments(issue)
%>
<%=comments.last().body%>