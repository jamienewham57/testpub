import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.user.util.UserManager
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.event.type.EventDispatchOption
 
def customFieldManager = ComponentAccessor.getCustomFieldManager()
 
def summary = issue.summary
def newStarterCF =  customFieldManager.getCustomFieldObjects(issue).find{it.name == "New Starter Name"}
def newStarterValue = issue.getCustomFieldValue(newStarterCF)
 
def finalValue = summary + " - " +  newStarterValue
 
def newIssue = (MutableIssue)issue
def issueManager = ComponentAccessor.getIssueManager();
def currentUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
newIssue.summary = finalValue
 
issueManager.updateIssue(currentUser, newIssue, EventDispatchOption.DO_NOT_DISPATCH, false)