/*
Project leader will be the first admin user.
Roles will be those by defaults.

*/

import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.canned.jira.admin.CopyProject
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
        def copyProject = new CopyProject()
        def target_name = issue.summary
log.debug("Target name is : " + target_name)
        def target_key = target_name.substring(0, Math.min(target_name.length(), 3)).toUpperCase()
log.debug("Target key is : " + target_key)
        def inputs = [
            (CopyProject.FIELD_SOURCE_PROJECT) : 'SOURCEKEY',
            (CopyProject.FIELD_TARGET_PROJECT) : target_key,
            (CopyProject.FIELD_TARGET_PROJECT_NAME) : target_name,
            (CopyProject.FIELD_COPY_VERSIONS) : true,
            (CopyProject.FIELD_COPY_COMPONENTS) : true,
            (CopyProject.FIELD_COPY_ISSUES) : false,
            (CopyProject.FIELD_COPY_GREENHOPPER) : true,
            (CopyProject.FIELD_COPY_DASH_AND_FILTERS) : false,
            // (CopyProject.FIELD_ORDER_BY) : "Rank",
        ]
        def errorCollection = copyProject.doValidate(inputs, false)
        if(errorCollection.hasAnyErrors()) {
            log.warn("Couldn't create project: $errorCollection")
        }
        else {
            def util = ComponentAccessor.getUserUtil()
            def adminsGroup = util.getGroupObject("jira-administrators")
            assert adminsGroup // must have jira-administrators group defined
            def admins = util.getAllUsersInGroups([adminsGroup])
            assert admins // must have at least one admin
            ComponentAccessor.getJiraAuthenticationContext().setLoggedInUser(util.getUserByName(admins.first().name))
            copyProject.doScript(inputs)
        }