import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.user.util.UserManager
import com.atlassian.crowd.embedded.api.User
  
def customFieldManager = ComponentAccessor.customFieldManager
//1st multi-user field
def 1stmultiuser = customFieldManager.getCustomFieldObject("customfield_XXXXX")
ArrayList<String> users= (ArrayList) issue.getCustomFieldValue(1stmultiuser) //collect users in a list from 1st multiuser field
//2nd multi-user field to update
def 2ndmultiuser = customFieldManager.getCustomFieldObject("customfield_XXXXX")
Collection<ApplicationUser> 2ndmultiuserlist= (Collection) issue.getCustomFieldValue(2ndmultiuser) //collect any previously updated values in 2nd multi-user field
//empty array list
ArrayList<ApplicationUser> list = new ArrayList<ApplicationUser>()
def currentUser = ComponentAccessor.getJiraAuthenticationContext()?.getLoggedInUser() //get current user
for ( int i = 0; i< users.size(); i++){ //go through each user in the 1st multi-user field
if(users.contains(currentUser) && users != 2ndmultiuserlist){ // if i contains current user and the current user doesn't already exist in the 2nd mutli-user
    if(2ndmultiuserlist != null){ //if 2nd multi user is not empty
    list.addAll(approvedbylist) //add the collection of list that was previously there
    list.add(currentUser) //+ add new user currentUser
        } else{ //if the 2nd multi-user list is empty
        approvedvalue.add(currentUser) //add currentuser
    }
issue.setCustomFieldValue(2ndmultiuser,list) //set the custom field value
    }
    }