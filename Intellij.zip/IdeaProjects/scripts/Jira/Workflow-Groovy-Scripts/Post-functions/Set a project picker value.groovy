import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.canned.jira.admin.CopyProject
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.ManagerFactory
import com.atlassian.jira.issue.ModifiedValue
import com.atlassian.jira.issue.IssueImpl
import com.atlassian.jira.issue.util.DefaultIssueChangeHolder
import com.atlassian.jira.project.ProjectManager
import com.atlassian.jira.project.ProjectImpl
def changeHolder = new DefaultIssueChangeHolder()
 
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
//get the project picker field : here it's originf
       def originf = customFieldManager.getCustomFieldObject('customfield_14303')
//get the key of the project : here because I have it in another field
def target_project_key = customFieldManager.getCustomFieldObject('customfield_14502')
        def target_key = issue.getCustomFieldValue(target_project_key).toString()
//I'm removing the spaces and set it in UpperCase to have a proper key
        def key = target_key.replaceAll("\\s","")
        def KEY = key.toUpperCase()
//getting the project functions
def projectManager = ComponentAccessor.getComponent(ProjectManager.class)
//getting my project from my key
            def project = projectManager.getProjectByCurrentKey(KEY)
//getting my project value for the project picker
    def projectValue= project.getGenericValue()
//updating my project picker.
         originf.updateValue(null, issue, new ModifiedValue(issue.getCustomFieldValue(originf), projectValue),changeHolder)
            issue.store()