/*
I'm using it to send random feedback from to customer (when issue = closed and CF = 5)
PF = Set Field Value to constant or Groovy expression
*/

import java.util.Random
Random rand = new Random() 
Double inte = (Double) rand.nextInt(5)
return inte