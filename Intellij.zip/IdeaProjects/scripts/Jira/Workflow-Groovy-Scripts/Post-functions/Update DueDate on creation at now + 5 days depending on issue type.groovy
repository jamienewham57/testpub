import java.sql.Timestamp
if (issue.getIssueType().getName() == "Conseil"){
    issue.setDueDate(new Timestamp((new Date() + 5).time))
}