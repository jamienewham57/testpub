import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.link.IssueLink
import com.atlassian.jira.issue.IssueInputParameters
import com.atlassian.jira.bc.issue.IssueService.CreateValidationResult
import com.atlassian.jira.bc.issue.IssueService.IssueResult
 
def userManager = ComponentAccessor.getUserManager()
def issueService = ComponentAccessor.getIssueService()
def issueLinkManager = ComponentAccessor.getIssueLinkManager()
 
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
def machinesF = customFieldManager.getCustomFieldObject('customfield_12103')
def machines = issue.getCustomFieldValue(machinesF).toString()
 
def listMachines = machines.split(",")
def currentUser = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
 
def defaultStatusId = "1"
def i = 0 
 
while (i < listMachines.length){
    IssueInputParameters issueInputParameters = issueService.newIssueInputParameters()
    issueInputParameters.setProjectId(issue.getProjectId())
    .setIssueTypeId(issue.getIssueTypeId())
    .setSummary(listMachines[i].toString())
    .setReporterId(issue.getReporterId())
    .setAssigneeId(issue.getAssigneeId())
    .addCustomFieldValue(machinesF.getIdAsLong(), listMachines[i].toString())
    .setStatusId(defaultStatusId)
    CreateValidationResult createValidationResult = issueService.validateCreate(currentUser, issueInputParameters)
    if (createValidationResult.isValid()){
        log.info("Start of creation")
            IssueResult createResult = issueService.create(currentUser, createValidationResult);
            def issueCreated = createResult.getIssue()
            def issueLinkId = (Long) 10100
            issueLinkManager.createIssueLink(issue.id, issueCreated.id, issueLinkId, (Long) 0, currentUser)
            log.info("End of creation, issue :" + issueCreated.getKey() + " is created" )      
            if (!createResult.isValid()) {
                log.info("validationResult errors :" + createResult.getErrorCollection().toString())
            }
        
    } else {
        //If KO, stop
            log.info("validationResult errors :" + createValidationResult.getErrorCollection().toString());
    }
    i++
}