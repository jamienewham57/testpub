import com.atlassian.jira.issue.IssueImpl
issue.summary = "["+issue.getKey()+"]"+ " " + issue.getSummary()