import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.ComponentManager
 
CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager()
ComponentManager componentManager = ComponentManager.getInstance()
 
//Text field
def cf1 = customFieldManager.getCustomFieldObject('customfield_XXXXX')
def cf1val = issue.getCustomFieldValue(cf1).toString()
  
 
//ArrayListField
def cf2 = customFieldManager.getCustomFieldObject('customfield_XXXXX')
 
ArrayList<String> cfcontent = new ArrayList<String>()
if (cf1val == "certain type of text"){
    cfcontent.add("value")
    issue.setCustomFieldValue(cf1, cfcontent)
}else{
    return false
}