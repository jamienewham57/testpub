/*
In this case I'm removing everything between () and the first and last character. (useful if you duplicate an insight field value to the summary)

*/

import com.atlassian.jira.issue.IssueImpl
def test = issue.getSummary() - ~/\((.*?)\)/
issue.summary = test.substring(1, test.length()-1)