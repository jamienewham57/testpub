import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
import org.apache.log4j.Category
import com.atlassian.jira.issue.link.IssueLink;
  
log = Category.getInstance("com.onresolve.jira.groovy.SubTasksAssignedToMe")
passesCondition = true
  
// Add other link types here, however for Blocks, to get a similar meaning,
// you will need to check inward links
linkType = ["Depends"]
  
linkMgr = ComponentManager.getInstance().getIssueLinkManager()
for (IssueLink link in linkMgr.getOutwardLinks(issue.id)) {
    if (linkType.contains(link.issueLinkType.name)) {
        if (! link.getDestinationObject().resolutionId) {
            passesCondition = false
        }
    }
  
}
log.debug("passesCondition: " + passesCondition)