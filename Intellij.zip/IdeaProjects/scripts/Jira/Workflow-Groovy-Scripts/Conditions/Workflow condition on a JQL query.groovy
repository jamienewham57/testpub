import com.atlassian.crowd.embedded.api.User
import com.atlassian.jira.bc.issue.search.SearchService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.user.util.UserUtil
import com.atlassian.jira.web.bean.PagerFilter
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.issue.MutableIssue
 
def customFieldManager = ComponentAccessor.customFieldManager
MutableIssue issue = issue
 
CustomField buildNumber = customFieldManager.getCustomFieldObject("customfield_10100")
def buildNumberValue = issue.getCustomFieldValue(buildNumber);
 
CustomField nFeedVersion = customFieldManager.getCustomFieldObject("customfield_11500")
def selectedVersionString = issue.getCustomFieldValue(nFeedVersion)?.iterator()?.next()
 
if(buildNumberValue != null && selectedVersionString) {
    jqlSearch = "project = "+issue.projectObject.id+" and affectedVersion = "+selectedVersionString+" and cf[10100]="+buildNumberValue+""
 
    SearchService searchService = ComponentAccessor.getComponent(SearchService.class)
    UserUtil userUtil = ComponentAccessor.getUserUtil()
    User user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
    IssueManager issueManager = ComponentAccessor.getIssueManager()
      
    if (!user) {
        user = userUtil.getUserObject('admin')
    }
      
    List<Issue> issues = null
      
    SearchService.ParseResult parseResult =  searchService.parseQuery(user, jqlSearch)
    if (parseResult.isValid()) {
        def searchResult = searchService.search(user, parseResult.getQuery(),
 
    PagerFilter.getUnlimitedFilter())
        issues = searchResult.issues.collect {issueManager.getIssueObject(it.id)}
    } else {
        log.error("Invalid JQL: " + jqlSearch);
    }
 
    if(issues.size > 0)
        passesCondition = false
 
}