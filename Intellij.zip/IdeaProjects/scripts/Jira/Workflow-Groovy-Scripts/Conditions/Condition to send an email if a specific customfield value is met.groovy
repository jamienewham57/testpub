import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.customfields.manager.OptionsManager
  
def componentManager = ComponentManager.instance
def optionsManager = ComponentManager.getComponentInstanceOfType(OptionsManager.class)
def customFieldManager = componentManager.getCustomFieldManager()
  
def cf1 = customFieldManager.getCustomFieldObjectByName("Supplier")
issue.getCustomFieldValue(cf1)?.name == "Xuber"