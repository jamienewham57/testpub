Type: class
Class: com.onresolve.jira.groovy.GroovyCondition
Arguments:
FIELD_PREVIEW_ISSUE = scriptFileName = com.onresolve.jira.groovy.canned.workflow.conditions.JqlQueryCondition
FIELD_JQL_QUERY = assignee = currentUser() AND "Peer Review Required?" = Yes