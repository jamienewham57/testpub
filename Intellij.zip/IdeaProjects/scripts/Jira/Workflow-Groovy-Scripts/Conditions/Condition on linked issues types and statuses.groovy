import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.link.IssueLink
import org.apache.log4j.Category
 
Boolean hasresolvedLink = true
 
def issueLinkManager = ComponentAccessor.issueLinkManager
 
for (IssueLink link in issueLinkManager.getOutwardLinks(issue.id)) {
    if (link.getIssueLinkType().getName()=="Triggers") {
        if(! link.getDestinationObject().resolutionId) {
            hasresolvedLink = false;
            passesCondition = false;
        }
    }
}