import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.project.ProjectManager
import com.atlassian.jira.security.ROLEs.ProjectRoleManager
import com.atlassian.jira.security.ROLEs.ProjectRoleActors
import com.atlassian.jira.component.ComponentAccessor
import org.apache.log4j.Category
import com.atlassian.jira.config.SubTaskManager 
Category log = log
log.setLevel(org.apache.log4j.Level.ERROR);

log.debug("Start condition: " + passesCondition)

//Manager 
ProjectManager projectManager = componentManager.getProjectManager();
ProjectRoleManager projectRoleManager = ComponentManager.getComponentInstanceOfType(ProjectRoleManager.class);

passesCondition = true;
String ROLE = "ROLE_NAME";

//Variable
boolean isInRole = false;

//Check if the current user is in P&C
ProjectRoleActors projectRoleActors = projectRoleManager.getProjectRoleActors(projectRoleManager.getProjectRole(ROLE), issue.getProjectObject());
isInRole = projectRoleActors.getUsers().contains(ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser());

if (isInRole){
	passesCondition = false	
}

log.debug("passesCondition: " + passesCondition);
log.debug("End condition: " + passesCondition);