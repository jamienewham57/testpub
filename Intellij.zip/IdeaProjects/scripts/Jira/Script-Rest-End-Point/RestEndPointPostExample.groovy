import com.onresolve.scriptrunner.runner.rest.common.CustomEndpointDelegate
import groovy.transform.BaseScript
import groovy.json.JsonBuilder

import javax.ws.rs.core.MultivaluedMap
import javax.ws.rs.core.Response
import org.apache.log4j.Category


Category log = Category.getInstance("com.onresolve.jira.groovy")
log.setLevel(org.apache.log4j.Level.DEBUG)

@BaseScript CustomEndpointDelegate delegate

postExample(
        httpMethod: "POST"
) { MultivaluedMap queryParams, String body ->

    def xmlSlurp = new XmlSlurper().parseText(body)
    log.debug "slurped XML : " + xmlSlurp

    log.debug "Value of XML Tag : " + xmlSlurp.example

    return Response.ok(new JsonBuilder(["Traitement": "Done"]).toString()).build()
}
