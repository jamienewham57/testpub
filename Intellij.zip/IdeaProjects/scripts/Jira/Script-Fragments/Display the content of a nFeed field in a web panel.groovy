import com.valiantys.nfeed.api.IFieldDisplayService
import com.atlassian.jira.issue.Issue
import com.atlassian.jira.component.ComponentAccessor
import com.onresolve.scriptrunner.runner.customisers.WithPlugin;

@WithPlugin("com.valiantys.jira.plugins.SQLFeed")


class NFeedDisplayService {

    Issue issue;
    String issueKey;
    Object plugin;
    Class serviceClass;
    Object fieldDisplayService;
    def context;

    void init(context) {
        this.context = context;
        issue = context.issue as Issue
        issueKey = issue.getKey();

        plugin = ComponentAccessor.getPluginAccessor().getPlugin("com.valiantys.jira.plugins.SQLFeed");
        serviceClass = plugin.getClassLoader().loadClass("com.valiantys.nfeed.api.IFieldDisplayService");

        fieldDisplayService = ComponentAccessor.getOSGiComponentInstanceOfType(serviceClass);
    }

    String getDisplay(fieldId) {

        String display = "";
        def issue = context.issue as Issue
        def issueKey = issue.getKey();

        Object issueDisplay = ((IFieldDisplayService)fieldDisplayService).getDisplayResult(issueKey, fieldId);

        if (issueDisplay != null) {
            if(!issueDisplay.hasError()) {
                if(issueDisplay.getDisplay() != null) {
                    display = issueDisplay.getDisplay();
                }
            }
        }

        return display;
    }
}



NFeedDisplayService displayService = new NFeedDisplayService();
displayService.init(context);
// TODO Change the custom field id
writer.write(displayService.getDisplay("customfield_14147"));
// Note - you can render more fields if you'd like
// writer.write(displayService.getDisplay("customfield_14148"));
