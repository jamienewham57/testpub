Issue: $issue Priority: $issue.priority.name Field: <% out << issue.getCustomFieldValue(componentManager.getCustomFieldManager().getCustomFieldObject("customfield_XXXXX"))%>
