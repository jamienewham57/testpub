/*
In order to get all the external comments, you will need to create a scripted field first as "Internal" / "External" label is stored as a Comment Property and it's not possible to import CommentPropertyService class into the GStringTemplate.

*/

import com.atlassian.jira.bc.issue.comment.property.CommentPropertyService
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.comments.Comment
import groovy.json.JsonSlurper
  
final SD_PUBLIC_COMMENT = "sd.public.comment"
   
def commentManager = ComponentAccessor.getCommentManager()
def commentPropertyService = ComponentAccessor.getComponent(CommentPropertyService)
   
def user = ComponentAccessor.getJiraAuthenticationContext().getLoggedInUser()
// get whether the comment is internal or not, null means no property found, maybe not an SD issue
 
def isExternal = { Comment comment ->
    def commentProperty = commentPropertyService.getProperty(user, comment.id, SD_PUBLIC_COMMENT).getEntityProperty().getOrNull()
    if (commentProperty) {
        def props = new JsonSlurper().parseText(commentProperty.getValue())
        return props['internal'] instanceof String ? !((String)props['internal']).toBoolean() : !props['internal']
    }
    else {
        null
    }
}
// Examples
 
String comments = ""
commentManager.getComments(issue).findAll { isExternal(it) }.each {
        comments += "<p style=\"border-bottom: 1px solid #DDD;\">" + "<strong>" + it.getAuthorFullName() + "</strong/> - " + it.getCreated().format("dd-MM-YYYY hh:mm") + "</p>" +
            it.getBody() + "<br/>"
    }
return comments

/*
Email Template
One the field has been created - you can call the custom field into the template

*/

<%
//get the scripted comment custom field
def customfieldManager = com.atlassian.jira.component.ComponentAccessor.getCustomFieldManager()
def comments = issue.getCustomFieldValue(customfieldManager.getCustomFieldObject("customfield_XXXXX"))
out << comments
%>