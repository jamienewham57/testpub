Please add you message here
 
<b>Summary:</b> $issue.summary
<br>
<b>Field 1:</b> <% out << issue.getCustomFieldValue(componentManager.getCustomFieldManager().getCustomFieldObject("customfield_XXXXX")).values()*.value%>
<br>