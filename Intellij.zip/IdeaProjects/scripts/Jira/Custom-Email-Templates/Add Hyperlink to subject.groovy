Please add you message here
 
<b>Summary:</b> $issue.summary
<br>
Click <a href="$baseUrl/browse/<PROJECTKEY>">here</a> to access project information in JIRA
Click <a href="$baseUrl/browse/$issue">here</a> to access the issue in JIRA