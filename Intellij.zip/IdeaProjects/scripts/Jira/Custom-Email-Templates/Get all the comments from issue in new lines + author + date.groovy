<%
def commentManager = com.atlassian.jira.component.ComponentAccessor.getCommentManager()
def comments = commentManager.getComments(issue)
comments?.each { comment ->
%>
<p style="border-bottom: 1px solid #DDD;">
<b><%=comment.authorFullName%> - <%=comment.created.format("YYYY-MM-dd hh:mm")%></b><br>
</p>
<%=comment.body%>
</p>
<%}%>