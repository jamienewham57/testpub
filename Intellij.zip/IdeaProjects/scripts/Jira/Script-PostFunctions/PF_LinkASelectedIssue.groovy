import com.atlassian.jira.issue.Issue
import com.atlassian.jira.issue.MutableIssue
import com.atlassian.jira.issue.IssueManager
import com.atlassian.jira.issue.CustomFieldManager
import com.atlassian.jira.issue.link.IssueLinkManager
import com.atlassian.jira.issue.fields.CustomField
import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.issue.link.IssueLinkTypeManager
import com.atlassian.jira.user.ApplicationUser
import com.atlassian.jira.security.JiraAuthenticationContext
import org.apache.log4j.Category
 
MutableIssue issue = issue
Category log = log
 
log.setLevel(org.apache.log4j.Level.DEBUG);
log.debug "Start PF";

//Manager
CustomFieldManager customFieldManager = ComponentAccessor.customFieldManager;
IssueManager issueManager = ComponentAccessor.getIssueManager();
IssueLinkManager issueLinkManager = ComponentAccessor.getIssueLinkManager();
IssueLinkTypeManager issueLinkTypeManager = ComponentAccessor.getComponentOfType((IssueLinkTypeManager.class);
JiraAuthenticationContext authenticationContext = ComponentAccessor.getJiraAuthenticationContext();

ApplicationUser user = authenticationContext.getLoggedInUser();
		
//CustomField
Long CF_ID_PARENT_TASK = 13738;
Long CF_ID_ISSUE_LINK = 13740;
Long SEQUENCE = 0;

//CustomFields
CustomField parentTaskIDCF = customFieldManager.getCustomFieldObject(CF_PARENT_TASK);
CustomField issueLinkCF = customFieldManager.getCustomFieldObject(CF_ID_ISSUE_LINK);

//Get Values on CF
Long parentTaskID = (Long)issue.getCustomFieldValue(parentTaskIDCF);
Long issueLinkID = (Long)issue.getCustomFieldValue(issueLinkCF);

//Business
if (parentTaskID) {
	MutableIssue parentIssue = issueManager.getIssueObject(parentTaskID);
	if (parentIssue) {
		log.debug "Parent Issue is get, start link creation";
		issueLinkManager.createIssueLink(issue.getId(), parentIssue.getId(), issueLinkID, SEQUENCE, user);
	}
} 
else {
    log.debug "Id is null";
}
log.debug "End PF";