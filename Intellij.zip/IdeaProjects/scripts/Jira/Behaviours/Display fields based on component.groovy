import com.atlassian.jira.ComponentManager
import org.ofbiz.core.entity.GenericValue
import com.onresolve.jira.groovy.user.FieldBehaviours
import com.onresolve.jira.groovy.user.FormField
import com.atlassian.jira.bc.project.component.ProjectComponent
 
ComponentManager componentManager = ComponentManager.getInstance() 
 
FormField formComponent = getFieldById (fieldChanged)
FormField formSubcomponent = getFieldByName ("Component X version")
FormField formSubcomponent2 = getFieldByName ("Component B Version")
  
   
Object componentFormValue = formComponent.getFormValue()
List componentIds = []
    if (componentFormValue instanceof List) {
        componentIds.addAll(componentFormValue as List)
    } else {
        // could be an empty string if all components are deselected
        if (componentFormValue) {
            componentIds.add(componentFormValue)
        }
    }
def value = 0
def value2 = 0
for (String componentId : componentIds) {
   GenericValue component = componentManager.getProjectManager().getComponent(Long.parseLong(componentId))
   switch (component?.get("name")){
    case "A" :
         value = 1
        break
         
    case "B" :
         value2 = 2
        break
    }
}
     if (value2 == 2 && value == 1) {
           formSubcomponent.setHidden(false)
           formSubcomponent2.setHidden(false)
           formSubcomponent.setRequired(true)
           formSubcomponent2.setRequired(true)
     }
     else if (value == 1 ) {
            formSubcomponent2.setHidden(false)
            formSubcomponent.setHidden(true)
            formSubcomponent2.setRequired(true)
     } else if (value2 == 2) {
            formSubcomponent2.setHidden(true)
            formSubcomponent.setHidden(false)
            formSubcomponent.setRequired(true)
     } else {
      formSubcomponent2.setHidden(true)
            formSubcomponent.setHidden(true)
     }
   