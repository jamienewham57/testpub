import com.atlassian.jira.component.ComponentAccessor
import com.atlassian.jira.ComponentManager
import com.atlassian.jira.issue.Issue
def customFieldManager = ComponentAccessor.getCustomFieldManager()
 
def field1 = customFieldManager.getCustomFieldObject("customfield_16203")
//def field1val = issue.getCustomFieldValue(field1)
def selectedProject = getFieldByName("Release").getValue().toString()
getFieldByName("Release Content").convertToMultiSelect([
    ajaxOptions: [
        url : getBaseUrl() + "/rest/scriptrunner-jira/latest/issue/picker",
        query: true, // keep going back to the sever for each keystroke
        // this information is passed to the server with each keystroke
        data: [
            currentJql: "project = eorc and issuetype in ('Change Content', 'Defect Content') and Release = '${selectedProject}' ORDER BY key ASC",
            label     : "Pick Changes and Defects content",
            // specify maximum number of issues to display, defaults to 10
            // max       : 5,
        ],
        formatResponse: "issue"
    ],
    css: "max-width: 500px; width: 500px",
])
getFieldByName("Deployed In").convertToMultiSelect([
    ajaxOptions: [
        url : getBaseUrl() + "/rest/scriptrunner-jira/latest/issue/picker",
        query: true, // keep going back to the sever for each keystroke
        // this information is passed to the server with each keystroke
        data: [
            currentJql: "project = eorc and issuetype in ('Environment') ORDER BY key ASC",
            label     : "Pick Environments",
            // specify maximum number of issues to display, defaults to 10
            // max       : 5,
        ],
        formatResponse: "issue"
    ],
    css: "max-width: 500px; width: 500px",
])
getFieldByName("Release Candidate").convertToSingleSelect([
    ajaxOptions: [
        url : getBaseUrl() + "/rest/scriptrunner-jira/latest/issue/picker",
        query: true, // keep going back to the sever for each keystroke
        // this information is passed to the server with each keystroke
        data: [
            currentJql: "project = eorc and issuetype in ('Release Candidate') ORDER BY key ASC",
            label     : "Pick Release Candidate",
            // specify maximum number of issues to display, defaults to 10
            // max       : 5,
        ],
        formatResponse: "issue"
    ],
    css: "max-width: 500px; width: 500px",
])