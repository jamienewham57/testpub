import java.util.Collection
  
//field is my cascading select list
FormField field = getFieldById(fieldChanged)
Collection fieldval = field1.getFormValue()
log.error("fieldVal = "+fieldval )
  
String fieldValParent = fieldval[0]
  
//jiraVersion and boVersion are my fields I want to display or not
FormField jiraVersion = getFieldById ("customfield_10203")
FormField boVersion = getFieldById ("customfield_10204")
  
//by default I hide every fields
boVersion.setHidden(true)
jiraVersion.setHidden(true)
  
//then I display them depending on my first cascading value
switch(fieldValParent ){
    case "10000" :
     jiraVersion.setHidden(false)
     break;
    case "10002" :
     boVersion.setHidden(false)
     break
}