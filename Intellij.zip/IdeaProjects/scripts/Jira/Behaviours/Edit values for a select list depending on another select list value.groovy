import java.util.Collection
import com.atlassian.jira.ComponentManager
import com.onresolve.jira.groovy.user.FieldBehaviours
import com.onresolve.jira.groovy.user.FormField
  
 ComponentManager componentManager = ComponentManager.getInstance()
  
  
 FormField category = getFieldById(fieldChanged)
 FormField subCategory = getFieldById("customfield_13935")
 
 def subCategoryValues = ["12538":"GAT","12539":"CRM"]
 categoryValue = category.getFormValue()
  
  
 Map fieldOptions = [:]
fieldOptions.put("-1", "None")
 
switch (categoryValue) {
    case "12535":
        fieldOptions.putAll(subCategoryValues)
        break
    case "12536":
        fieldOptions.putAll(subCategoryValues)
        break
 case "12537":
        fieldOptions.putAll(subCategoryValues)
        break
    default:
        fieldOptions.put("-1", "None")
        break         
}
subCategory.setFieldOptions(fieldOptions)