import com.onresolve.jira.groovy.user.FieldBehaviours
import com.onresolve.jira.groovy.user.FormField
  
    FormField fixVersionField = getFieldById(fieldChanged)
    Object fieldFormValue = fixVersionField.getValue();
  
    if(!fieldFormValue) {
       fixVersionField.setError("<div>The field \"Fix Version/s\" should be filled in.</div>")
    } else {
        fixVersionField.setError("")
    }