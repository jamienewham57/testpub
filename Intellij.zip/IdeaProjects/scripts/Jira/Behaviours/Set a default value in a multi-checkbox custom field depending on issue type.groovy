import com.onresolve.jira.groovy.user.FieldBehaviours
import com.onresolve.jira.groovy.user.FormField
        FormField frmCheckboxes = getFieldByName("Teams")
        FormField issueType = getFieldById(getFieldChanged())
        if (getActionName()== "Create"){
            switch(issueType.getValue()) {
             case "10006" :
                  if ( !frmCheckboxes.getFormValue() || frmCheckboxes.getFormValue() == "[]") {
                       frmCheckboxes.setFormValue([10000])
                  }
                  break
             default :
                   frmCheckboxes.setFormValue([])
                   break
           }
       }