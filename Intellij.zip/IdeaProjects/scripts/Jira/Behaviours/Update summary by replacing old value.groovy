def ProductValue = getFieldById (getFieldChanged())
def String productType = ProductValue.getValue()
def formSummary = getFieldById("summary")

def String currentSummary = formSummary.getValue()
currentSummary = (currentSummary)?.replaceAll('Recrutement interne', '')
currentSummary = (currentSummary)?.replaceAll('Prestataire de service', '')
currentSummary = (currentSummary)?.replaceAll('Stagiaire, Apprenti', '')

if (productType != null){
    def String newSummary = productType + " " + currentSummary
    formSummary.setFormValue(newSummary)
}else{
    formSummary.setFormValue(productType)
}