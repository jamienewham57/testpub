import com.onresolve.jira.groovy.user.FormField;

/*
 * How to display and mark as required a nFeed field based on the value of a Multi select field (native)?
 *
 * customfield_12419 is a native Jira multi values select with two options: "Jira" and "Confluence"
 * customfield_12500 is a nFeed field - visible and required only if "Jira" is selected in the select list
 * customfield_12501 is a nFeed field - visible and required only if "Confluence" is selected in the select list
*/

// Select list options selected
List<String> accessesRequested = Arrays.asList((String[]) getFieldById("customfield_12419").getFormValue())

// nFeed field - Jira
FormField nFeedJira = getFieldById("customfield_12500")
String jiraOptionId = "10709";
boolean jiraIsSelected = accessesRequested.contains(jiraOptionId);
nFeedJira.setHidden(!jiraIsSelected);
nFeedJira.setRequired(jiraIsSelected);

// nFeed field - Confluence
String confluenceOptionId = "10708";
boolean confluenceIsSelected = accessesRequested.contains(confluenceOptionId);
FormField nFeedConfluence = getFieldById("customfield_12501")
nFeedConfluence.setHidden(!confluenceIsSelected);
nFeedConfluence.setRequired(confluenceIsSelected);
