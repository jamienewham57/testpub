import com.atlassian.jira.component.ComponentAccessor
 
 
def customFieldManager = ComponentAccessor.getCustomFieldManager()
def optionsManager = ComponentAccessor.getOptionsManager()
 
def formField = getFieldByName("Criticité") // *name* of your custom field
def customField = customFieldManager.getCustomFieldObject(formField.getFieldId())
def config = customField.getRelevantConfig(getIssueContext())
def options = optionsManager.getOptions(config)
 
def optionsMap = options.findAll {
    it.value in ["Majeure", "Elevée", "Normale", "Basse"] // list of options you want to show
}.collectEntries {
    [
        (it.optionId.toString()) : it.value
    ]
}
 
formField.setFieldOptions(optionsMap)