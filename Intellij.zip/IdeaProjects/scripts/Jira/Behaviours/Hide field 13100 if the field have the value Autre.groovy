def ProductValue = getFieldById (getFieldChanged())
 
def HiddenFieldName1 = getFieldById ("customfield_13100") // id for champ personalise
 
def producttype = ProductValue.getValue()
 
 
if (producttype.equals("Autre")) {
    HiddenFieldName1.setHidden(false)
}
else {
    HiddenFieldName1.setHidden(true)
    HiddenFieldName1.setFormValue("")
}