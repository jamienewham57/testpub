/*
* Title: Number of characters per page body
* Author: Atlassian
* Last Change by: reto.gehring@valiantys.com
* Date: 23.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL
* Description: Number of characters per page body
* Doc Link: 
*
*/
SELECT MAX(blength), MIN(blength), AVG(blength), STDDEV(blength), VARIANCE(blength) 
FROM (SELECT LENGTH(bodycontent.body) AS blength 
      FROM bodycontent, content 
      WHERE bodycontent.contentid = content.contentid AND contenttype='PAGE'
     ) AS bodylengths
WHERE blength > 0;