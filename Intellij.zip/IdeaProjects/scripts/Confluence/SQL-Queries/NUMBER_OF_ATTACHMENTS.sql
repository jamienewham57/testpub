/*
* Title: Number of attachments 
* Author: Atlassian
* Last Change by: reto.gehring@valiantys.com
* Date: 23.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL
* Description: Number of attachments and other information
* Doc Link: 
*
*/
SELECT COUNT(*), MAX(filesize), MIN(filesize), AVG(filesize), STDDEV(filesize), SUM(filesize) FROM attachments;