Author: reto.gehring@valiantys.com
Date: 10.10.2018


This is the place to store Confluence SQL Querries

For the moment I'm not sure if we should have a folder for each DB Type. For the beginning I propose that we are 
adding the DB Type in the file name, if the querry is specific to a DB Type.

E.g. 
- GET-ALL-INACTIVE-USERS-MYSQL.sql
- GET-ALL-INACTIVE-USERS-MSSQL.sql
- GET-ALL-INACTIVE-USERS-PSQL.sql
- GET-ALL-INACTIVE-USERS-ORA.sql