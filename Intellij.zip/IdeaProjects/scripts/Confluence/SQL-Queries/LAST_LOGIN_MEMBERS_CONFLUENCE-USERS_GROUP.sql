/*
* Title: Last login of all members of the confluence-users group
* Author: Atlassian
* Last Change by: reto.gehring@valiantys.com
* Date: 12.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL
* Description: Query to get the last login of all members of the confluence-users group
* Doc Link: 
*
*/
SELECT distinct u.lower_user_name, l.successdate
FROM cwd_user u
LEFT JOIN logininfo l ON u.user_name = l.username
JOIN cwd_membership m ON u.id = m.child_user_id
JOIN cwd_group g ON m.parent_id = g.id
JOIN spacepermissions sp ON g.group_name = sp.permgroupname
WHERE permtype='USECONFLUENCE' order by u.lower_user_name;