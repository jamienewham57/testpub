/*
* Title: Number of attachments per page
* Author: Atlassian
* Last Change by: reto.gehring@valiantys.com
* Date: 23.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL
* Description: Number of attachments per page
* Doc Link: 
*
*/
SELECT COUNT(*) AS pages_with_attachments, AVG(attachments_per_page), MAX(attachments_per_page), MIN(attachments_per_page), STDDEV(attachments_per_page) FROM
( SELECT COUNT(*) AS attachments_per_page FROM attachments GROUP BY attachments.pageid ) AS app;