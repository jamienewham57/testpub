/*
* Title: Content created per day
* Author: Atlassian
* Last Change by: reto.gehring@valiantys.com
* Date: 17.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL
* Description: Content created per day (set date)
* Doc Link: 
*
*/
SELEC;T contenttype, MIN(number_of_changes), MAX(number_of_changes), AVG(number_of_changes)
FROM (
    SELECT contenttype, DATE_TRUNC('day', creationdate) , COUNT(*) AS number_of_changes 
    FROM content 
    WHERE content.creationdate > DATE '2017-05-17' AND version = 1
    GROUP BY contenttype, DATE_TRUNC('day', creationdate)        
     ) AS dates
GROUP BY contenttype;