/*
* Title: Returns the number of archived spaces
* Author: reto.gehring@valiantys.com
* Last Change by: reto.gehring@valiantys.com
* Date: 12.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL, MSSQL
* Description: Returns the number of archived spaces
* Doc Link: 
*
*/
SELECT COUNT(spacestatus) FROM spaces WHERE spacestatus = 'ARCHIVED';