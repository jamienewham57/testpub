/*
* Title: Spaces with DOC Template
* Author: Atlassian
* Last Change by: reto.gehring@valiantys.com
* Date: 12.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL, MSSQL,
* Description: Lists all spaces with the document template applied. This spaces must be migrated when moving to version 6.X
* Doc Link: https://confluence.atlassian.com/confkb/evaluating-documentation-theme-to-default-theme-migration-impact-in-confluence-856702148.html
*
*/
SELECT spaces.spacekey,spaces.spacename FROM bandana
   JOIN spaces ON bandana.bandanacontext = spaces.spacekey
   WHERE bandanakey='atlassian.confluence.theme.settings'
   AND bandanavalue LIKE '%<string>com.atlassian.confluence.plugins.doctheme:documentation</string>%';