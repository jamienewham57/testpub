/*
* Title: Content edited per day
* Author: Atlassian
* Last Change by: reto.gehring@valiantys.com
* Date: 17.05.2017
* 
* Atlassian Tool: Confluence
* Tested DBs: PSQL
* Description: Content edited per day (change date)
* Doc Link: 
*
*/
SELECT contenttype, MIN(number_of_changes), MAX(number_of_changes), AVG(number_of_changes)
FROM (
    SELECT contenttype, DATE_TRUNC('day', lastmoddate) AS changedate, COUNT(*) AS number_of_changes 
    FROM content 
    WHERE content.creationdate > DATE '2017-05-17'
    GROUP BY contenttype, DATE_TRUNC('day', lastmoddate)        
     ) as dates
GROUP BY contenttype;