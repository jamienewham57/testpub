// This macro displays all consultants skills from Ostinato / Insight
// Data is retrieved using REST API and  then displayed in a table

import com.atlassian.confluence.xhtml.api.XhtmlContent
import com.atlassian.sal.api.component.ComponentLocator
import com.onresolve.scriptrunner.runner.ScriptRunnerImpl
import groovy.xml.MarkupBuilder
import groovyx.net.http.ContentType
import groovyx.net.http.HTTPBuilder
import groovyx.net.http.Method
import com.atlassian.confluence.user.UserAccessor
import com.atlassian.user.User
def httpBuilder = new HTTPBuilder("https://ostinato.valiantys.com/")
def xhtmlContent = ComponentLocator.getComponent(XhtmlContent)
def userAccessor = ComponentLocator.getComponent(UserAccessor)

def user = userAccessor.getUser("${parameters.consultant}")

def writer = new StringWriter()
def builder = new MarkupBuilder(writer)

// Collecting skill categories
def rt = httpBuilder.request(Method.GET, ContentType.JSON) {
    uri.path = "rest/insight/1.0/iql/objects"
    //uri.query = [objectSchemaId:"1",iql:"objectType=Skill categories",resultPerPage:"150"]
    uri.query = [objectSchemaId:"1",iql:"objectType=\"Skill categories\"",resultPerPage:"150"]    
    headers.'Authorization' =
        "Basic ${"charlie:XXXXXXXXX".bytes.encodeBase64().toString()}"
}
List<Map> skillCategories = rt.objectEntries
Map<String,List<String>> skillsByCategory = new TreeMap<String,List<String>>()
skillCategories.sort{it.order}.each { skillCategory ->
    def skillCategoryLabel = skillCategory.label
    
	// Collecting skills
    def iql3 = "object having outboundReferences(Name = \""+skillCategoryLabel.toString()+"\") and objectType=\"Skill\""    
    def rt3 = httpBuilder.request(Method.GET, ContentType.JSON) {
        uri.path = "rest/insight/1.0/iql/objects"
        uri.query = [objectSchemaId:"1",iql:iql3,resultPerPage:"150"]
        headers.'Authorization' =
            "Basic ${"charlie:XXXXXXXXX".bytes.encodeBase64().toString()}"
    }
    
    List<Map> skills = rt3.objectEntries
    
    skills.sort{it.order}.each { skill ->
        def skillLabel = skill.label
        if(!skillsByCategory.containsKey(skillCategoryLabel)) {
            List<String> skillsList = new ArrayList<String>()
            skillsList.add(skillLabel)
            skillsByCategory.put(skillCategoryLabel,skillsList)
        } else {
            List<String> skillsList = skillsByCategory.get(skillCategoryLabel)
            skillsList.add(skillLabel)
            skillsByCategory.put(skillCategoryLabel,skillsList)
        }
    }
}

// Collecting matching user
def rt2 = httpBuilder.request(Method.GET, ContentType.JSON) {
    uri.path = "rest/insight/1.0/iql/objects"
    uri.query = [objectSchemaId:"1",iql:"objectType=Users and Name=\""+user.getFullName()+"\" and object having outboundReferences(objectType=Knowledge)",resultPerPage:"150"]
    headers.'Authorization' =
        "Basic ${"charlie:XXXXXXXXX".bytes.encodeBase64().toString()}"
}
List<Map> consultants = rt2.objectEntries
Map<String,List<String>> skillsMap = new TreeMap<String,List<String>>()
consultants.sort{it.order}.each { consultant -> 
	consultant.attributes.find { it.objectTypeAttributeId == 23}.each { it ->
        def consultantName = consultant.label
        def key = it.key
        def value = it.value
        if(key.equals("objectAttributeValues")) {
            value.each{ skills ->
                skills.each { skill ->
                    def skillKey = skill.key
                    def skillValue = skill.value
                    if(skillKey.equals("referencedObject")) {
                        def skillName = skillValue.getAt("name").toString()
                        if(!skillsMap.containsKey(skillName)) {
                            List<String> newConsultant = new ArrayList<String>()
                            newConsultant.add(consultant.label)
                            skillsMap.put(skillName,newConsultant)
                        } else {
                            List<String> existingConsultants = skillsMap.get(skillName)
                            existingConsultants.add(consultant.label)
                            skillsMap.put(skillName,existingConsultants)
                        }
                    }
                }
            }
        }
    }
}
    
builder.html{
        table {
        tbody {
            tr {
                th { p("Consultants") }
                th { p("Skill category") }            
                th { p("Skills")}
            }
            for (consultant in consultants) {
                tr {
                    td(rowspan:12)  { 
                         p(consultant.label)
                    }
                    for (skillCategory in skillCategories){
                        tr{ 
                            td{p(skillCategory.label)}
                            td{
                                for (category in skillsByCategory){
                                    if(category.key.toString().equals(skillCategory.label)){
                                        category.value.each { skill ->
                                        def skillLabel = skill
                                            boolean emptySkill = true;
                                            for(int i = 5; i >= 0 ; i--) {
                                                def consultantsList = skillsMap.get(skillLabel.toString() + " (Level "+i+")")
                                                consultantsList.each{ consultantToto ->
                                                    if (consultantToto.equals(consultant.label)){
                                                        emptySkill = false;
                                                        p{
                                                        yield(skillLabel)
                                                            for(int j = 0; j < i ; j++) {
                                                            builder.'ac:emoticon' ('ac:name': "yellow-star")
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (emptySkill != false){
                                                p{yield(skillLabel) + 'ac:emoticon' ('ac:name': "cross")}
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
    
xhtmlContent.convertStorageToView(writer.toString(), context)